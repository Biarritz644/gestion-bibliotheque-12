package com.bibliotheque.ui;

import java.awt.Color;
import java.awt.Font;

/**
 * Thème SIMPLE MODERNE - Palette cohérente et unifiée
 */
public class UITheme {

    // Palette principale - Cohérence totale
    public static final Color BG_MAIN = new Color(18, 25, 35);           // fond sombre profond
    public static final Color BG_SECONDARY = new Color(28, 36, 50);      // panel secondaire légèrement plus clair
    public static final Color BORDER_SUBTLE = new Color(45, 55, 75);     // bord cohérent
    public static final Color TEXT_PRIMARY = new Color(240, 245, 255);   // texte clair
    public static final Color TEXT_SECONDARY = new Color(170, 180, 200); // texte secondaire

    // Couleur d'accent principale - Bleu moderne cohérent
    public static final Color ACCENT = new Color(66, 135, 245);          // bleu principal
    public static final Color ACCENT_LIGHT = new Color(100, 160, 255);   // bleu clair (hover)
    public static final Color ACCENT_DARK = new Color(52, 110, 200);     // bleu foncé (pressed)

    // Couleurs d'action cohérentes avec l'accent
    public static final Color ACTION_ADD = new Color(76, 160, 100);      // vert (cohérent)
    public static final Color ACTION_EDIT = new Color(66, 135, 245);     // bleu (accent)
    public static final Color ACTION_DELETE = new Color(220, 85, 85);    // rouge (cohérent)
    public static final Color ACTION_SAVE = new Color(66, 135, 245);     // bleu (accent)
    public static final Color ACTION_CANCEL = new Color(120, 130, 150);  // gris neutre

    public static final Color FOCUS_BLUE = new Color(100, 160, 255);     // focus (accent light)

    // Palette pour la page de connexion (belge, marrons, chauds)
    public static final Color LOGIN_BG = new Color(212, 175, 135);       // belge/chamois
    public static final Color LOGIN_CARD = new Color(100, 75, 60);       // marron foncé
    public static final Color LOGIN_ACCENT = new Color(160, 120, 90);    // marron clair
    public static final Color LOGIN_PAPER = new Color(240, 230, 215);    // papier crème
    public static final Color LOGIN_BUTTON_RED = new Color(200, 60, 60); // rouge bouton connexion
    public static final Color LOGIN_BUTTON_BLACK = new Color(50, 50, 50);// noir bouton annuler

    // Polices - Système simple et clair
    public static final Font TITLE_FONT = new Font("Segoe UI", Font.BOLD, 26);
    public static final Font HEADER_FONT = new Font("Segoe UI", Font.BOLD, 18);
    public static final Font BODY_FONT = new Font("Segoe UI", Font.PLAIN, 14);
    public static final Font BUTTON_FONT = new Font("Segoe UI", Font.BOLD, 13);
    public static final Font TABLE_FONT = new Font("Segoe UI", Font.PLAIN, 14);
    public static final Font TABLE_HEADER_FONT = new Font("Segoe UI", Font.BOLD, 13);

    // Constantes dimensionnelles
    public static final int BUTTON_RADIUS = 8;
    public static final int TABLE_ROW_HEIGHT = 32;
    public static final int DIALOG_MIN_WIDTH = 520;
    public static final int DIALOG_MIN_HEIGHT = 650;
    public static final int MAIN_WINDOW_WIDTH = 1000;
    public static final int MAIN_WINDOW_HEIGHT = 700;
}
