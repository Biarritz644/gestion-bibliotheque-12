package com.bibliotheque.ui;

import com.bibliotheque.model.Emprunt;
import com.bibliotheque.model.Client;
import com.bibliotheque.model.Livre;

import javax.swing.*;
import java.awt.*;
import java.time.LocalDate;

public class EmpruntFormDialog extends JDialog {

    private static final long serialVersionUID = 7385386665469966491L;
    
    private JTextField txtDateEmprunt;
    private JTextField txtDateRetourPrevu;
    private JTextField txtDateRetourReel;
    private JTextField txtClientId;
    private JTextField txtLivreId;

    private boolean confirmed = false;
    private Emprunt emprunt;

    public EmpruntFormDialog(JFrame parent, Emprunt emprunt) {
        super(parent, "MODIFIER EMPRUNT", true);
        
        this.emprunt = emprunt;
        
        setSize(500, 450);
        setLocationRelativeTo(parent);
        setResizable(false);

        // Main panel
        JPanel mainPanel = new JPanel(new BorderLayout());
        UIUtils.stylePanel(mainPanel);
        mainPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        // Header
        JPanel headerPanel = new JPanel(new BorderLayout());
        headerPanel.setBackground(UITheme.BG_SECONDARY);
        String empruntTitle = emprunt == null ? "Nouvel Emprunt" : "Emprunt ID : " + emprunt.getId();
        JLabel titleLabel = UIUtils.createTitleLabel(empruntTitle);
        headerPanel.add(titleLabel, BorderLayout.CENTER);
        headerPanel.setBorder(BorderFactory.createEmptyBorder(0, 0, 20, 0));
        mainPanel.add(headerPanel, BorderLayout.NORTH);

        // Form panel
        JPanel formPanel = new JPanel(new GridLayout(6, 2, 15, 15));
        formPanel.setBackground(UITheme.BG_SECONDARY);
        formPanel.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));

        // Initialize fields
        txtDateEmprunt = new JTextField(emprunt.getDateEmprunt().toString());
        UIUtils.styleTextField(txtDateEmprunt);
        
        txtDateRetourPrevu = new JTextField(emprunt.getDateRetourPrevu().toString());
        UIUtils.styleTextField(txtDateRetourPrevu);

        txtDateRetourReel = new JTextField(
                emprunt.getDateRetourReel() == null ? "" : emprunt.getDateRetourReel().toString()
        );
        UIUtils.styleTextField(txtDateRetourReel);

        txtClientId = new JTextField(String.valueOf(emprunt.getClient().getId()));
        UIUtils.styleTextField(txtClientId);
        
        txtLivreId = new JTextField(String.valueOf(emprunt.getLivre().getId()));
        UIUtils.styleTextField(txtLivreId);

        // Date Emprunt
        JLabel lblDateEmp = new JLabel("DATE EMPRUNT (YYYY-MM-DD)");
        lblDateEmp.setFont(UITheme.BODY_FONT);
        lblDateEmp.setForeground(UITheme.TEXT_PRIMARY);
        formPanel.add(lblDateEmp);
        formPanel.add(txtDateEmprunt);

        // Retour Prévu
        JLabel lblDatePrev = new JLabel("RETOUR PRÉVU (YYYY-MM-DD)");
        lblDatePrev.setFont(UITheme.BODY_FONT);
        lblDatePrev.setForeground(UITheme.TEXT_PRIMARY);
        formPanel.add(lblDatePrev);
        formPanel.add(txtDateRetourPrevu);

        // Retour Réel
        JLabel lblDateReel = new JLabel("RETOUR RÉEL (YYYY-MM-DD)");
        lblDateReel.setFont(UITheme.BODY_FONT);
        lblDateReel.setForeground(UITheme.TEXT_PRIMARY);
        formPanel.add(lblDateReel);
        formPanel.add(txtDateRetourReel);

        // Client ID
        JLabel lblClient = new JLabel("ID CLIENT");
        lblClient.setFont(UITheme.BODY_FONT);
        lblClient.setForeground(UITheme.TEXT_PRIMARY);
        formPanel.add(lblClient);
        formPanel.add(txtClientId);

        // Livre ID
        JLabel lblLivre = new JLabel("ID LIVRE");
        lblLivre.setFont(UITheme.BODY_FONT);
        lblLivre.setForeground(UITheme.TEXT_PRIMARY);
        formPanel.add(lblLivre);
        formPanel.add(txtLivreId);

        mainPanel.add(formPanel, BorderLayout.CENTER);

        // Button panel
        JPanel btnPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 15, 15));
        btnPanel.setBackground(UITheme.BG_SECONDARY);

        JButton btnOk = new JButton("ENREGISTRER");
        UIUtils.styleButton(btnOk, UITheme.ACTION_SAVE);
        JButton btnCancel = new JButton("ANNULER");
        UIUtils.styleButton(btnCancel, UITheme.ACTION_CANCEL);

        btnPanel.add(btnOk);
        btnPanel.add(btnCancel);

        mainPanel.add(btnPanel, BorderLayout.SOUTH);

        setContentPane(mainPanel);

        // Event listeners
        btnOk.addActionListener(e -> {
            try {
                int clientId = Integer.parseInt(txtClientId.getText());
                int livreId = Integer.parseInt(txtLivreId.getText());

                this.emprunt = new Emprunt(
                        emprunt.getId(),
                        new Livre(livreId, null, null, 0, 0),
                        new Client(clientId, null, 0, null),
                        LocalDate.parse(txtDateEmprunt.getText()),
                        LocalDate.parse(txtDateRetourPrevu.getText()),
                        txtDateRetourReel.getText().isEmpty()
                                ? null
                                : LocalDate.parse(txtDateRetourReel.getText()),
                        emprunt.getStatut(),
                        emprunt.getAmende()
                );

                confirmed = true;
                dispose();

            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Valeur invalide !",
                        "Erreur", JOptionPane.ERROR_MESSAGE);
            }
        });

        btnCancel.addActionListener(e -> dispose());
    }

    public boolean isConfirmed() {
        return confirmed;
    }

    public Emprunt getEmprunt() {
        return emprunt;
    }
}