package com.bibliotheque.ui;

import javax.swing.*;
import javax.swing.table.DefaultTableCellRenderer;
import java.awt.*;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

/**
 * Utilitaires UI - Application des styles thème
 */
public class UIUtils {

    public static final Font TITLE_FONT = UITheme.TITLE_FONT;
    public static final Font BODY_FONT = UITheme.BODY_FONT;
    public static final Font BUTTON_FONT = UITheme.BUTTON_FONT;

    public static void styleTable(JTable table) {
        table.setBackground(UITheme.BG_SECONDARY);
        table.setForeground(UITheme.TEXT_PRIMARY);
        table.setFont(UITheme.TABLE_FONT);
        table.setRowHeight(UITheme.TABLE_ROW_HEIGHT);
        table.setSelectionBackground(new Color(58, 134, 255, 100));
        table.setSelectionForeground(UITheme.TEXT_PRIMARY);
        table.setGridColor(UITheme.BORDER_SUBTLE);
        table.setShowHorizontalLines(true);
        table.setShowVerticalLines(false);
        table.setIntercellSpacing(new Dimension(0, 1));

        table.getTableHeader().setBackground(UITheme.BORDER_SUBTLE);
        table.getTableHeader().setForeground(UITheme.TEXT_PRIMARY);
        table.getTableHeader().setFont(UITheme.TABLE_HEADER_FONT);
        table.getTableHeader().setPreferredSize(new Dimension(0, UITheme.TABLE_ROW_HEIGHT));
        table.getTableHeader().setBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, UITheme.BORDER_SUBTLE));

        DefaultTableCellRenderer renderer = new DefaultTableCellRenderer() {
            public Component getTableCellRendererComponent(JTable table, Object value,
                    boolean isSelected, boolean hasFocus, int row, int column) {
                super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
                setBackground(isSelected ? new Color(58, 134, 255, 100) : UITheme.BG_SECONDARY);
                setForeground(UITheme.TEXT_PRIMARY);
                setFont(UITheme.TABLE_FONT);
                setBorder(BorderFactory.createEmptyBorder(5, 10, 5, 10));
                return this;
            }
        };

        for (int i = 0; i < table.getColumnCount(); i++) {
            table.getColumnModel().getColumn(i).setCellRenderer(renderer);
        }
    }

    public static void styleTextField(JTextField textField) {
        textField.setBackground(UITheme.BORDER_SUBTLE);
        textField.setForeground(UITheme.TEXT_PRIMARY);
        textField.setCaretColor(UITheme.TEXT_PRIMARY);
        textField.setFont(UITheme.BODY_FONT);
        textField.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(UITheme.BORDER_SUBTLE, 1),
                BorderFactory.createEmptyBorder(8, 10, 8, 10)
        ));

        textField.addFocusListener(new FocusAdapter() {
            public void focusGained(FocusEvent e) {
                textField.setBorder(BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(UITheme.FOCUS_BLUE, 2),
                        BorderFactory.createEmptyBorder(8, 10, 8, 10)
                ));
            }
            public void focusLost(FocusEvent e) {
                textField.setBorder(BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(UITheme.BORDER_SUBTLE, 1),
                        BorderFactory.createEmptyBorder(8, 10, 8, 10)
                ));
            }
        });
    }

    public static void stylePasswordField(JPasswordField passwordField) {
        passwordField.setBackground(UITheme.BORDER_SUBTLE);
        passwordField.setForeground(UITheme.TEXT_PRIMARY);
        passwordField.setCaretColor(UITheme.TEXT_PRIMARY);
        passwordField.setFont(UITheme.BODY_FONT);
        passwordField.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(UITheme.BORDER_SUBTLE, 1),
                BorderFactory.createEmptyBorder(8, 10, 8, 10)
        ));

        passwordField.addFocusListener(new FocusAdapter() {
            public void focusGained(FocusEvent e) {
                passwordField.setBorder(BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(UITheme.FOCUS_BLUE, 2),
                        BorderFactory.createEmptyBorder(8, 10, 8, 10)
                ));
            }
            public void focusLost(FocusEvent e) {
                passwordField.setBorder(BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(UITheme.BORDER_SUBTLE, 1),
                        BorderFactory.createEmptyBorder(8, 10, 8, 10)
                ));
            }
        });
    }

    public static void styleButton(JButton button, Color color) {
        button.setBackground(color);
        button.setForeground(UITheme.TEXT_PRIMARY);
        button.setFont(UITheme.BUTTON_FONT);
        button.setBorderPainted(false);
        button.setFocusPainted(false);
        button.setContentAreaFilled(true);
        button.setOpaque(true);
        button.setMargin(new Insets(10, 20, 10, 20));

        button.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) {
                button.setBackground(brighten(color, 1.15f));
                button.setCursor(new Cursor(Cursor.HAND_CURSOR));
            }
            public void mouseExited(MouseEvent e) {
                button.setBackground(color);
            }
            public void mousePressed(MouseEvent e) {
                button.setBackground(darken(color, 0.9f));
            }
            public void mouseReleased(MouseEvent e) {
                button.setBackground(brighten(color, 1.15f));
            }
        });
    }

    public static void styleComboBox(JComboBox<?> comboBox) {
        comboBox.setBackground(UITheme.BORDER_SUBTLE);
        comboBox.setForeground(UITheme.TEXT_PRIMARY);
        comboBox.setFont(UITheme.BODY_FONT);
    }

    public static void stylePanel(JPanel panel) {
        panel.setBackground(UITheme.BG_MAIN);
    }

    public static void styleScrollPane(JScrollPane scrollPane) {
        scrollPane.setBackground(UITheme.BG_SECONDARY);
        scrollPane.getViewport().setBackground(UITheme.BG_SECONDARY);
    }

    public static JLabel createLogoLabel() {
        JLabel logo = new JLabel("📚");
        logo.setFont(new Font("Arial", Font.PLAIN, 32));
        logo.setForeground(UITheme.ACTION_ADD);
        return logo;
    }

    public static JLabel createTitleLabel(String text) {
        JLabel title = new JLabel(text, SwingConstants.CENTER);
        title.setFont(UITheme.HEADER_FONT);
        title.setForeground(UITheme.TEXT_PRIMARY);
        title.setHorizontalAlignment(SwingConstants.CENTER);
        return title;
    }

    private static Color brighten(Color color, float factor) {
        int r = (int) Math.min(255, color.getRed() * factor);
        int g = (int) Math.min(255, color.getGreen() * factor);
        int b = (int) Math.min(255, color.getBlue() * factor);
        return new Color(r, g, b);
    }

    private static Color darken(Color color, float factor) {
        int r = (int) (color.getRed() * factor);
        int g = (int) (color.getGreen() * factor);
        int b = (int) (color.getBlue() * factor);
        return new Color(r, g, b);
    }
}
