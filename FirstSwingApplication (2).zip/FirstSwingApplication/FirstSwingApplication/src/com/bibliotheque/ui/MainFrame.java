package com.bibliotheque.ui;

import javax.swing.*;


import javax.swing.table.TableRowSorter;

import java.awt.*;

import com.bibliotheque.dao.ClientDAO;
import com.bibliotheque.dao.EmpruntDAO;
import com.bibliotheque.dao.LivreDAO;
import com.bibliotheque.ui.ClientTableModel;
import com.bibliotheque.model.Client;
import com.bibliotheque.model.Emprunt;
import com.bibliotheque.model.Livre;
import java.sql.Connection;
import java.sql.Statement;
 

import com.bibliotheque.util.DatabaseConnection;

public class MainFrame extends JFrame {
	private JPanel createLivrePanel(){

	    JPanel panel = new JPanel(new BorderLayout());
        UIUtils.stylePanel(panel);

	    LivreTableModel model = new LivreTableModel();

	    JTable table = new JTable(model);
        UIUtils.styleTable(table);
        
        final TableRowSorter<LivreTableModel> sorter = new TableRowSorter<>(model);
        table.setRowSorter(sorter);

        JTextField txtRecherche = new JTextField(20);
        UIUtils.styleTextField(txtRecherche);
        txtRecherche.setToolTipText("Rechercher...");
        
        txtRecherche.getDocument().addDocumentListener(new javax.swing.event.DocumentListener() {
            private void filter() {
                String text = txtRecherche.getText();

                if (text.trim().length() == 0) {
                    sorter.setRowFilter(null);
                } else {
                    sorter.setRowFilter(RowFilter.regexFilter("(?i)" + text, 1, 2));
                }
            }

            @Override
            public void insertUpdate(javax.swing.event.DocumentEvent e) { filter(); }

            @Override
            public void removeUpdate(javax.swing.event.DocumentEvent e) { filter(); }

            @Override
            public void changedUpdate(javax.swing.event.DocumentEvent e) { filter(); }
        });

        JScrollPane scrollPane = new JScrollPane(table);
        UIUtils.styleScrollPane(scrollPane);

        JPanel topPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 15, 10));
        topPanel.setBackground(UITheme.BG_SECONDARY);
        JLabel lblSearch = new JLabel("🔍 RECHERCHER :");
        lblSearch.setFont(UITheme.BODY_FONT);
        lblSearch.setForeground(UITheme.TEXT_PRIMARY);
        topPanel.add(lblSearch);
        topPanel.add(txtRecherche);

	    panel.add(topPanel, BorderLayout.NORTH);
	    panel.add(scrollPane, BorderLayout.CENTER);

	    LivreDAO dao = new LivreDAO();

	    try {
	        model.setLivres(dao.getAllLivres());
	    } catch (Exception e) {
	        e.printStackTrace();
	    }

        JButton btnAjouter = new JButton("➕ AJOUTER");
        UIUtils.styleButton(btnAjouter, UITheme.ACTION_ADD);
        
        JButton btnSupprimer = new JButton("🗑️ SUPPRIMER");
        UIUtils.styleButton(btnSupprimer, UITheme.ACTION_DELETE);
        
        JButton btnModifier = new JButton("✏️ MODIFIER");
        UIUtils.styleButton(btnModifier, UITheme.ACTION_EDIT);

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 15));
        buttonPanel.setBackground(UITheme.BG_SECONDARY);
        buttonPanel.add(btnAjouter);
        buttonPanel.add(btnModifier);
        buttonPanel.add(btnSupprimer);

	    panel.add(buttonPanel, BorderLayout.SOUTH);
	    
	    btnAjouter.addActionListener(e -> {
	        LivreFormDialog dialog = new LivreFormDialog(this, null);
	        dialog.setVisible(true);

	        if(dialog.isConfirmed()){
	            try {
	                dao.ajouterLivre(dialog.getLivre());
	                model.setLivres(dao.getAllLivres());
	            } catch (Exception ex) {
	                ex.printStackTrace();
	            }
	        }
	    });

		btnSupprimer.addActionListener(e -> {
		int selectedRow = table.getSelectedRow();

		if(selectedRow != -1){
			int confirm = JOptionPane.showConfirmDialog(
					this,
					"Voulez-vous vraiment supprimer ce livre ?",
					"Confirmation",
					JOptionPane.YES_NO_OPTION
			);

			if(confirm == JOptionPane.YES_OPTION){
				int modelRow = table.convertRowIndexToModel(selectedRow);
				int id = (int) model.getValueAt(modelRow, 0);

				try {
					dao.supprimerLivre(id);
					model.setLivres(dao.getAllLivres());
				} catch (Exception ex) {
					ex.printStackTrace();
				}
			}
		}
	});

		btnModifier.addActionListener(e -> {
		int selectedRow = table.getSelectedRow();

		if(selectedRow != -1){
			int modelRow = table.convertRowIndexToModel(selectedRow);
			int id = (int) model.getValueAt(modelRow, 0);
			String titre = (String) model.getValueAt(modelRow, 1);
			String auteur = (String) model.getValueAt(modelRow, 2);
			int annee = (int) model.getValueAt(modelRow, 3);
			int quantite = (int) model.getValueAt(modelRow, 4);

			Livre livre = new Livre(id, titre, auteur, annee, quantite);

			LivreFormDialog dialog = new LivreFormDialog(this, livre);
			dialog.setVisible(true);

			if(dialog.isConfirmed()){
				try {
					dao.modifierLivre(dialog.getLivre());
					model.setLivres(dao.getAllLivres());
				} catch (Exception ex) {
					ex.printStackTrace();
				}
			}
		}
	});

	    return panel;
	}

	
	private JPanel createClientPanel(){

	    JPanel panel = new JPanel(new BorderLayout());
        UIUtils.stylePanel(panel);

	    ClientTableModel model = new ClientTableModel();
	    JTable table = new JTable(model);
        UIUtils.styleTable(table);
        
        final TableRowSorter<ClientTableModel> sorter = new TableRowSorter<>(model);
        table.setRowSorter(sorter);

	    JTextField txtRecherche = new JTextField(20);
        UIUtils.styleTextField(txtRecherche);
        txtRecherche.setToolTipText("Rechercher...");

        txtRecherche.getDocument().addDocumentListener(new javax.swing.event.DocumentListener() {
            private void filter() {
                String text = txtRecherche.getText();

                if (text.trim().isEmpty()) {
                    sorter.setRowFilter(null);
                } else {
                    sorter.setRowFilter(RowFilter.regexFilter("(?i)" + text));
                }
            }

            public void insertUpdate(javax.swing.event.DocumentEvent e) { filter(); }
            public void removeUpdate(javax.swing.event.DocumentEvent e) { filter(); }
            public void changedUpdate(javax.swing.event.DocumentEvent e) { filter(); }
        });

        JPanel topPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 15, 10));
        topPanel.setBackground(UITheme.BG_SECONDARY);
        JLabel lblSearch = new JLabel("🔍 RECHERCHER :");
        lblSearch.setFont(UITheme.BODY_FONT);
        lblSearch.setForeground(UITheme.TEXT_PRIMARY);
        topPanel.add(lblSearch);
        topPanel.add(txtRecherche);

	    panel.add(topPanel, BorderLayout.NORTH);

	    JScrollPane scrollPane = new JScrollPane(table);
        UIUtils.styleScrollPane(scrollPane);
	    panel.add(scrollPane, BorderLayout.CENTER);

	    ClientDAO dao = new ClientDAO();

	    try {
	        model.setClients(dao.getAllClients());
	    } catch (Exception e) {
	        e.printStackTrace();
	    }

        JButton btnAjouter = new JButton("➕ AJOUTER");
        UIUtils.styleButton(btnAjouter, UITheme.ACTION_ADD);
        
        JButton btnSupprimer = new JButton("🗑️ SUPPRIMER");
        UIUtils.styleButton(btnSupprimer, UITheme.ACTION_DELETE);
        
        JButton btnModifier = new JButton("✏️ MODIFIER");
        UIUtils.styleButton(btnModifier, UITheme.ACTION_EDIT);

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 15));
        buttonPanel.setBackground(UITheme.BG_SECONDARY);
        buttonPanel.add(btnAjouter);
        buttonPanel.add(btnModifier);
        buttonPanel.add(btnSupprimer);
	    panel.add(buttonPanel, BorderLayout.SOUTH);

	    btnAjouter.addActionListener(e -> {
	        ClientFormDialog dialog = new ClientFormDialog(this, null);
	        dialog.setVisible(true);

	        if(dialog.isConfirmed()){
	            try {
	                dao.ajouterClient(dialog.getClient());
	                model.setClients(dao.getAllClients());
	            } catch (Exception ex) {
	                ex.printStackTrace();
	            }
	        }
	    });

	    btnSupprimer.addActionListener(e -> {
	        int selectedRow = table.getSelectedRow();

	        if(selectedRow != -1){
	            int modelRow = table.convertRowIndexToModel(selectedRow);

	            int confirm = JOptionPane.showConfirmDialog(
	                    this,
	                    "Voulez-vous vraiment supprimer ce Lecteur ?",
	                    "Confirmation",
	                    JOptionPane.YES_NO_OPTION
	            );

	            if(confirm == JOptionPane.YES_OPTION){
	                int id = (int) model.getValueAt(modelRow, 0);

	                try {
	                    dao.supprimerClient(id);
	                    model.setClients(dao.getAllClients());
	                } catch (Exception ex) {
	                    ex.printStackTrace();
	                }
	            }
	        }
	    });

	    btnModifier.addActionListener(e -> {
	        int selectedRow = table.getSelectedRow();

	        if(selectedRow != -1){
	            int modelRow = table.convertRowIndexToModel(selectedRow);

	            int id = (int) model.getValueAt(modelRow, 0);
	            String nom = (String) model.getValueAt(modelRow, 1);
	            int age = (int) model.getValueAt(modelRow, 2);
	            String sexe = (String) model.getValueAt(modelRow, 3);

	            Client client = new Client(id, nom, age, sexe);

	            ClientFormDialog dialog = new ClientFormDialog(this, client);
	            dialog.setVisible(true);

	            if(dialog.isConfirmed()){
	                try {
	                    dao.modifierClient(dialog.getClient());
	                    model.setClients(dao.getAllClients());
	                } catch (Exception ex) {
	                    ex.printStackTrace();
	                }
	            }
	        }
	    });

	    return panel;
	}
	private JPanel createEmpruntPanel(){

	    JPanel panel = new JPanel(new BorderLayout());
        UIUtils.stylePanel(panel);

	    EmpruntTableModel model = new EmpruntTableModel();
	    JTable table = new JTable(model);
        UIUtils.styleTable(table);
        
        JScrollPane scrollPane = new JScrollPane(table);
        UIUtils.styleScrollPane(scrollPane);
        panel.add(scrollPane, BorderLayout.CENTER);

        EmpruntDAO dao = new EmpruntDAO();
        try {
	        model.setEmprunts(dao.getAllEmprunts());
	    } catch (Exception e) {
	        e.printStackTrace();
	    }

        JButton btnAjouter = new JButton("NOUVEL EMPRUNT");
        UIUtils.styleButton(btnAjouter, UITheme.ACTION_ADD);
        
        JButton btnRetour = new JButton("RETOUR LIVRE");
        UIUtils.styleButton(btnRetour, UITheme.ACTION_EDIT);
        
        JButton btnModifier = new JButton("MODIFIER");
        UIUtils.styleButton(btnModifier, UITheme.ACTION_EDIT);
        
        JButton btnSupprimer = new JButton("SUPPRIMER");
        UIUtils.styleButton(btnSupprimer, UITheme.ACTION_DELETE);
	    
        JPanel bottomPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 15));
        bottomPanel.setBackground(UITheme.BG_SECONDARY);
        bottomPanel.add(btnAjouter);
        bottomPanel.add(btnRetour);
	    bottomPanel.add(btnModifier);
	    bottomPanel.add(btnSupprimer);

	    panel.add(bottomPanel, BorderLayout.SOUTH);

	    btnAjouter.addActionListener(e -> {
	        String clientIdStr = JOptionPane.showInputDialog(this, "ID Client :", "Nouvel Emprunt", JOptionPane.INFORMATION_MESSAGE);
	        
	        if(clientIdStr != null && !clientIdStr.isEmpty()) {
	            String livreIdStr = JOptionPane.showInputDialog(this, "ID Livre :", "Nouvel Emprunt", JOptionPane.INFORMATION_MESSAGE);

	            try {
	                int clientId = Integer.parseInt(clientIdStr);
	                int livreId = Integer.parseInt(livreIdStr);

	                dao.ajouterEmprunt(clientId, livreId);
	                model.setEmprunts(dao.getAllEmprunts());

	                JOptionPane.showMessageDialog(this, "Emprunt créé avec succès", "Succès", JOptionPane.INFORMATION_MESSAGE);

	            } catch (Exception ex) {
	                JOptionPane.showMessageDialog(this, ex.getMessage(), "Erreur", JOptionPane.ERROR_MESSAGE);
	            }
	        }
	    }); 

	    btnRetour.addActionListener(e -> {
	        int selectedRow = table.getSelectedRow();

	        if(selectedRow != -1){
	            int modelRow = table.convertRowIndexToModel(selectedRow);
	            int id = (int) model.getValueAt(modelRow, 0);
	            String statut = (String) model.getValueAt(modelRow, 6);

	            if(statut.equals("EN_COURS") || statut.equals("EN_LITIGE")){
	                try {
	                    dao.retournerLivre(id);
	                    model.setEmprunts(dao.getAllEmprunts());
	                    JOptionPane.showMessageDialog(this, "Retour effectué", "Succès", JOptionPane.INFORMATION_MESSAGE);
	                } catch (Exception ex) {
	                    ex.printStackTrace();
	                }
	            } else {
	                JOptionPane.showMessageDialog(this, "Cet emprunt est déjà terminé", "Info", JOptionPane.INFORMATION_MESSAGE);
	            }
	        }
	    });
	    
	    btnSupprimer.addActionListener(e -> {
	        int selectedRow = table.getSelectedRow();

	        if(selectedRow != -1){
	            int modelRow = table.convertRowIndexToModel(selectedRow);
	            int id = (int) model.getValueAt(modelRow, 0);

	            int confirm = JOptionPane.showConfirmDialog(
	                    this,
	                    "Supprimer cet emprunt ?",
	                    "Confirmation",
	                    JOptionPane.YES_NO_OPTION
	            );

	            if(confirm == JOptionPane.YES_OPTION){
	                try {
	                    dao.supprimerEmprunt(id);
	                    model.setEmprunts(dao.getAllEmprunts());
	                } catch (Exception ex) {
	                    ex.printStackTrace();
	                }
	            }
	        }
	    });
	    
	    btnModifier.addActionListener(e -> {
	        int selectedRow = table.getSelectedRow();

	        if(selectedRow != -1){
	            int modelRow = table.convertRowIndexToModel(selectedRow);
	            int id = (int) model.getValueAt(modelRow, 0);

	            try {
	                Emprunt emprunt = dao.getEmpruntById(id);
	                EmpruntFormDialog dialog = new EmpruntFormDialog(this, emprunt);
	                dialog.setVisible(true);

	                if(dialog.isConfirmed()){
	                    dao.modifierEmprunt(dialog.getEmprunt());
	                    model.setEmprunts(dao.getAllEmprunts());
	                }

	            } catch (Exception ex){
	                ex.printStackTrace();
	            }
	        }
	    });

	    return panel;
	}

    public MainFrame(){
        setTitle("GESTION BIBLIOTHÈQUE - Système Professionnel");
        setSize(UITheme.MAIN_WINDOW_WIDTH, UITheme.MAIN_WINDOW_HEIGHT);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        // Main panel styling
        JPanel mainPanel = new JPanel(new BorderLayout());
        UIUtils.stylePanel(mainPanel);

        // header with logo and title
        JPanel header = new JPanel(new BorderLayout(15, 0));
        header.setBackground(UITheme.BG_SECONDARY);
        header.setBorder(BorderFactory.createMatteBorder(0, 0, 2, 0, UITheme.BORDER_SUBTLE));
        header.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));
        
        JLabel logoLabel = UIUtils.createLogoLabel();
        header.add(logoLabel, BorderLayout.WEST);
        
        JLabel title = new JLabel("GESTION BIBLIOTHÈQUE", SwingConstants.CENTER);
        title.setFont(UITheme.TITLE_FONT);
        title.setForeground(UITheme.TEXT_PRIMARY);
        header.add(title, BorderLayout.CENTER);
        
        mainPanel.add(header, BorderLayout.NORTH);

        // Tabs avec style moderne
        JTabbedPane tabs = new JTabbedPane();
        tabs.setBackground(UITheme.BG_SECONDARY);
        tabs.setForeground(UITheme.TEXT_PRIMARY);
        tabs.setFont(UITheme.BUTTON_FONT);
        tabs.setOpaque(true);

        tabs.add("LIVRES", createLivrePanel());
        tabs.add("CLIENTS", createClientPanel());
        tabs.add("EMPRUNTS", createEmpruntPanel());

        mainPanel.add(tabs, BorderLayout.CENTER);
        
        add(mainPanel);
    }

	public static void main(String[] args) {

		// If running in mock mode, skip DB schema initialization to allow UI tests
		if (!DatabaseConnection.isMock()) {
			try (Connection conn = DatabaseConnection.getConnection();
				 Statement stmt = conn.createStatement()) {

				String sql = """
					CREATE TABLE IF NOT EXISTS livre (
						id INTEGER PRIMARY KEY AUTOINCREMENT,
						titre TEXT,
						auteur TEXT,
						anneeEdition INTEGER,
						quantite INTEGER,
						disponible INTEGER
					);
				""";

				stmt.execute(sql);

				String sqlClient = """
						CREATE TABLE IF NOT EXISTS client (
							id INTEGER PRIMARY KEY AUTOINCREMENT,
							nom TEXT,
							age INTEGER,
							sexe TEXT
						);
					""";

				stmt.execute(sqlClient);

				String sqlEmprunt = """
							CREATE TABLE IF NOT EXISTS emprunt (
								id INTEGER PRIMARY KEY AUTOINCREMENT,
								client_id INTEGER,
								livre_id INTEGER,
								date_emprunt TEXT,
								date_retour_prevu TEXT,
								date_retour_reel TEXT,
								statut TEXT,
								amende INTEGER
							);
						""";

				stmt.execute(sqlEmprunt);

				String sqlAdmin = """
						  CREATE TABLE IF NOT EXISTS admin (
								id INTEGER PRIMARY KEY AUTOINCREMENT,
								username TEXT UNIQUE,
								password TEXT
							);
						""";

				stmt.execute(sqlAdmin);

				String insertAdmin = """
							INSERT OR IGNORE INTO admin (id, username, password)
							VALUES (1, 'admin', 'admin123');
						""";

				stmt.execute(insertAdmin);

			} catch (Exception e) {
				e.printStackTrace();
			}
		}

		SwingUtilities.invokeLater(() -> {
			JFrame dummy = new JFrame();
			dummy.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

			LoginDialog login = new LoginDialog(dummy);
			login.setVisible(true);

			if (login.isAuthenticated()) {
				dummy.dispose();
				new MainFrame().setVisible(true);
			} else {
				System.exit(0);
			}
		});
	}
}
