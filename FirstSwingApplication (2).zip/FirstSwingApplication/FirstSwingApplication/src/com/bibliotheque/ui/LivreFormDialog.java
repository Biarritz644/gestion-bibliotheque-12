package com.bibliotheque.ui;

import com.bibliotheque.model.Livre;

import javax.swing.*;
import java.awt.*;

public class LivreFormDialog extends JDialog {

    private JTextField txtTitre = new JTextField(20);
    private JTextField txtAuteur = new JTextField(20);
    private JTextField txtAnnee = new JTextField(5);
    private JTextField txtQuantite = new JTextField(5);

    private boolean confirmed = false;
    private Livre livre;

    public LivreFormDialog(JFrame parent, Livre livre) {
        super(parent, true);
        
        this.livre = livre;
        
        setTitle(livre == null ? "AJOUTER LIVRE" : "MODIFIER LIVRE");
        setSize(500, 350);
        setLocationRelativeTo(parent);
        setResizable(false);

        // Main panel
        JPanel mainPanel = new JPanel(new BorderLayout());
        UIUtils.stylePanel(mainPanel);
        mainPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        // Header
        JPanel headerPanel = new JPanel(new BorderLayout());
        headerPanel.setBackground(UITheme.BG_SECONDARY);
        String titleText = livre == null ? "Ajouter Livre" : "Modifier : " + livre.getTitre();
        JLabel titleLabel = UIUtils.createTitleLabel(titleText);
        headerPanel.add(titleLabel, BorderLayout.CENTER);
        headerPanel.setBorder(BorderFactory.createEmptyBorder(0, 0, 20, 0));
        mainPanel.add(headerPanel, BorderLayout.NORTH);

        // Form panel
        JPanel formPanel = new JPanel(new GridLayout(4, 2, 15, 15));
        formPanel.setBackground(UITheme.BG_SECONDARY);
        formPanel.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));

        // Titre
        JLabel lblTitre = new JLabel("TITRE");
        lblTitre.setFont(UITheme.BODY_FONT);
        lblTitre.setForeground(UITheme.TEXT_PRIMARY);
        formPanel.add(lblTitre);
        UIUtils.styleTextField(txtTitre);
        formPanel.add(txtTitre);

        // Auteur
        JLabel lblAuteur = new JLabel("AUTEUR");
        lblAuteur.setFont(UITheme.BODY_FONT);
        lblAuteur.setForeground(UITheme.TEXT_PRIMARY);
        formPanel.add(lblAuteur);
        UIUtils.styleTextField(txtAuteur);
        formPanel.add(txtAuteur);

        // Année
        JLabel lblAnnee = new JLabel("ANNÉE");
        lblAnnee.setFont(UITheme.BODY_FONT);
        lblAnnee.setForeground(UITheme.TEXT_PRIMARY);
        formPanel.add(lblAnnee);
        UIUtils.styleTextField(txtAnnee);
        formPanel.add(txtAnnee);

        // Quantité
        JLabel lblQuantite = new JLabel("QUANTITÉ");
        lblQuantite.setFont(UITheme.BODY_FONT);
        lblQuantite.setForeground(UITheme.TEXT_PRIMARY);
        formPanel.add(lblQuantite);
        UIUtils.styleTextField(txtQuantite);
        formPanel.add(txtQuantite);

        mainPanel.add(formPanel, BorderLayout.CENTER);

        // Button panel
        JPanel btnPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 15, 15));
        btnPanel.setBackground(UITheme.BG_SECONDARY);

        JButton btnOk = new JButton("ENREGISTRER");
        UIUtils.styleButton(btnOk, UITheme.ACTION_SAVE);
        JButton btnCancel = new JButton("ANNULER");
        UIUtils.styleButton(btnCancel, UITheme.ACTION_CANCEL);

        btnPanel.add(btnOk);
        btnPanel.add(btnCancel);

        mainPanel.add(btnPanel, BorderLayout.SOUTH);

        setContentPane(mainPanel);

        // Populate existing data
        if (livre != null) {
            txtTitre.setText(livre.getTitre());
            txtAuteur.setText(livre.getAuteur());
            txtAnnee.setText(String.valueOf(livre.getAnneeEdition()));
            txtQuantite.setText(String.valueOf(livre.getQuantite()));
        }

        // Event listeners
        btnOk.addActionListener(e -> {
            confirmed = true;
            dispose();
        });

        btnCancel.addActionListener(e -> dispose());
    }

    public boolean isConfirmed() {
        return confirmed;
    }

    public Livre getLivre() {
        String titre = txtTitre.getText();
        String auteur = txtAuteur.getText();
        int annee = Integer.parseInt(txtAnnee.getText());
        int quantite = Integer.parseInt(txtQuantite.getText());

        if (livre == null) {
            return new Livre(0, titre, auteur, annee, quantite);
        } else {
            return new Livre(livre.getId(), titre, auteur, annee, quantite);
        }
    }
}
