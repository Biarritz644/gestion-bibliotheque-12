package com.bibliotheque.ui;

import com.bibliotheque.model.Client;

import javax.swing.*;
import java.awt.*;

public class ClientFormDialog extends JDialog {

    private static final long serialVersionUID = -3426018041311635280L;

    private JTextField txtNom = new JTextField(20);
    private JTextField txtAge = new JTextField(5);
    private JComboBox<String> cbSexe = new JComboBox<>(new String[]{"Homme", "Femme"});

    private boolean confirmed = false;
    private Client client;

    public ClientFormDialog(JFrame parent, Client client) {
        super(parent, true);

        this.client = client;

        setTitle(client == null ? "AJOUTER CLIENT" : "MODIFIER CLIENT");
        setSize(450, 300);
        setLocationRelativeTo(parent);
        setResizable(false);

        // Main panel
        JPanel mainPanel = new JPanel(new BorderLayout());
        UIUtils.stylePanel(mainPanel);
        mainPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        // Header
        JPanel headerPanel = new JPanel(new BorderLayout());
        headerPanel.setBackground(UITheme.BG_SECONDARY);
        String titleText = client == null ? "Ajouter Client" : "Modifier : " + client.getNom();
        JLabel titleLabel = UIUtils.createTitleLabel(titleText);
        headerPanel.add(titleLabel, BorderLayout.CENTER);
        headerPanel.setBorder(BorderFactory.createEmptyBorder(0, 0, 20, 0));
        mainPanel.add(headerPanel, BorderLayout.NORTH);

        // Form panel
        JPanel formPanel = new JPanel(new GridLayout(3, 2, 15, 15));
        formPanel.setBackground(UITheme.BG_SECONDARY);
        formPanel.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));

        // Nom
        JLabel lblNom = new JLabel("NOM");
        lblNom.setFont(UITheme.BODY_FONT);
        lblNom.setForeground(UITheme.TEXT_PRIMARY);
        formPanel.add(lblNom);
        UIUtils.styleTextField(txtNom);
        formPanel.add(txtNom);

        // Age
        JLabel lblAge = new JLabel("ÂGE");
        lblAge.setFont(UITheme.BODY_FONT);
        lblAge.setForeground(UITheme.TEXT_PRIMARY);
        formPanel.add(lblAge);
        UIUtils.styleTextField(txtAge);
        formPanel.add(txtAge);

        // Sexe
        JLabel lblSexe = new JLabel("SEXE");
        lblSexe.setFont(UITheme.BODY_FONT);
        lblSexe.setForeground(UITheme.TEXT_PRIMARY);
        formPanel.add(lblSexe);
        UIUtils.styleComboBox(cbSexe);
        formPanel.add(cbSexe);

        mainPanel.add(formPanel, BorderLayout.CENTER);

        // Button panel
        JPanel btnPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 15, 15));
        btnPanel.setBackground(UITheme.BG_SECONDARY);

        JButton btnOk = new JButton("ENREGISTRER");
        UIUtils.styleButton(btnOk, UITheme.ACTION_SAVE);
        JButton btnCancel = new JButton("ANNULER");
        UIUtils.styleButton(btnCancel, UITheme.ACTION_CANCEL);

        btnPanel.add(btnOk);
        btnPanel.add(btnCancel);

        mainPanel.add(btnPanel, BorderLayout.SOUTH);

        setContentPane(mainPanel);

        // Populate existing data
        if (client != null) {
            txtNom.setText(client.getNom());
            txtAge.setText(String.valueOf(client.getAge()));
            cbSexe.setSelectedItem(client.getSexe());
        }

        // Event listeners
        btnOk.addActionListener(e -> {
            confirmed = true;
            dispose();
        });

        btnCancel.addActionListener(e -> dispose());
    }

    public boolean isConfirmed() {
        return confirmed;
    }

    public Client getClient() {
        String nom = txtNom.getText();
        int age = Integer.parseInt(txtAge.getText());
        String sexe = cbSexe.getSelectedItem().toString();

        if (client == null) {
            return new Client(0, nom, age, sexe);
        } else {
            return new Client(client.getId(), nom, age, sexe);
        }
    }
}
