package com.bibliotheque.ui;

import com.bibliotheque.model.Emprunt;

import javax.swing.table.AbstractTableModel;
import java.util.ArrayList;
import java.util.List;

public class EmpruntTableModel extends AbstractTableModel {

    private static final long serialVersionUID = 1L;

    private List<Emprunt> emprunts = new ArrayList<>();

    private final String[] columns = {
            "ID",
            "Client",
            "Livre",
            "Date Emprunt",
            "Retour Prévu",
            "Retour Réel",
            "Statut",
            "Amende"
    };

    public void setEmprunts(List<Emprunt> emprunts){
        this.emprunts = emprunts;
        fireTableDataChanged();
    }

    @Override
    public int getRowCount() {
        return emprunts.size();
    }

    @Override
    public int getColumnCount() {
        return columns.length;
    }

    @Override
    public String getColumnName(int column) {
        return columns[column];
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {

        Emprunt e = emprunts.get(rowIndex);

        switch (columnIndex){
            case 0: return e.getId();
            case 1: return e.getClient().getNom();
            case 2: return e.getLivre().getTitre();
            case 3: return e.getDateEmprunt();
            case 4: return e.getDateRetourPrevu();
            case 5: return e.getDateRetourReel();
            case 6: return e.getStatut();
            case 7: return e.getAmende() + " FC";
            default: return null;
        }
    }
}