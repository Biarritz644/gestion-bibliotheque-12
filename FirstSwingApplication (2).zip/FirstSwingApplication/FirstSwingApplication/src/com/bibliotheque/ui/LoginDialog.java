package com.bibliotheque.ui;

import javax.swing.*;
import java.awt.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.bibliotheque.util.DatabaseConnection;

public class LoginDialog extends JDialog {

    private boolean authenticated = false;

    public LoginDialog(JFrame parent) {
        super(parent, "Connexion - Gestion Bibliothèque", true);

        setSize(500, 450);
        setLocationRelativeTo(parent);
        setResizable(false);

        // Main panel - fond belge chaud
        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.setBackground(UITheme.LOGIN_BG);
        mainPanel.setBorder(BorderFactory.createEmptyBorder(30, 30, 30, 30));

        // Central card-style panel avec marron foncé
        JPanel cardPanel = new JPanel(new BorderLayout());
        cardPanel.setBackground(UITheme.LOGIN_CARD);
        cardPanel.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(UITheme.LOGIN_ACCENT, 2),
            BorderFactory.createEmptyBorder(30, 30, 30, 30)
        ));
        mainPanel.add(cardPanel, BorderLayout.CENTER);

        // Header - logo et titre
        JPanel headerPanel = new JPanel(new BorderLayout());
        headerPanel.setBackground(UITheme.LOGIN_CARD);
        headerPanel.setBorder(BorderFactory.createEmptyBorder(0, 0, 25, 0));

        JLabel bigLogo = new JLabel("📚", SwingConstants.CENTER);
        bigLogo.setFont(new Font("Segoe UI", Font.PLAIN, 64));
        bigLogo.setForeground(UITheme.LOGIN_ACCENT);
        headerPanel.add(bigLogo, BorderLayout.NORTH);

        JLabel titleLabel = new JLabel("ADMINISTRATEUR", SwingConstants.CENTER);
        titleLabel.setFont(UITheme.TITLE_FONT);
        titleLabel.setForeground(UITheme.LOGIN_PAPER);
        headerPanel.add(titleLabel, BorderLayout.CENTER);

        cardPanel.add(headerPanel, BorderLayout.NORTH);

        // Form panel
        JPanel formPanel = new JPanel(new GridLayout(2, 1, 0, 20));
        formPanel.setBackground(UITheme.LOGIN_CARD);

        // Username
        JPanel userPanel = new JPanel(new BorderLayout(10, 0));
        userPanel.setBackground(UITheme.LOGIN_CARD);
        JLabel lblUser = new JLabel("Utilisateur:");
        lblUser.setFont(UITheme.BODY_FONT);
        lblUser.setForeground(UITheme.LOGIN_PAPER);
        lblUser.setPreferredSize(new Dimension(120, 0));
        JTextField txtUsername = new JTextField();
        styleLoginField(txtUsername);
        userPanel.add(lblUser, BorderLayout.WEST);
        userPanel.add(txtUsername, BorderLayout.CENTER);

        // Password
        JPanel passPanel = new JPanel(new BorderLayout(10, 0));
        passPanel.setBackground(UITheme.LOGIN_CARD);
        JLabel lblPass = new JLabel("Mot de passe:");
        lblPass.setFont(UITheme.BODY_FONT);
        lblPass.setForeground(UITheme.LOGIN_PAPER);
        lblPass.setPreferredSize(new Dimension(120, 0));
        JPasswordField txtPassword = new JPasswordField();
        styleLoginField(txtPassword);
        passPanel.add(lblPass, BorderLayout.WEST);
        passPanel.add(txtPassword, BorderLayout.CENTER);

        formPanel.add(userPanel);
        formPanel.add(passPanel);

        cardPanel.add(formPanel, BorderLayout.CENTER);

        // Button panel
        JPanel btnPanel = new JPanel(new GridLayout(1, 2, 15, 0));
        btnPanel.setBackground(UITheme.LOGIN_CARD);
        btnPanel.setBorder(BorderFactory.createEmptyBorder(25, 0, 0, 0));

        JButton btnLogin = new JButton("CONNEXION");
        styleLoginButton(btnLogin, UITheme.LOGIN_BUTTON_RED);

        JButton btnCancel = new JButton("ANNULER");
        styleLoginButton(btnCancel, UITheme.LOGIN_BUTTON_BLACK);

        btnPanel.add(btnLogin);
        btnPanel.add(btnCancel);

        cardPanel.add(btnPanel, BorderLayout.SOUTH);

        setContentPane(mainPanel);

        // Event handling
        btnLogin.addActionListener(e -> {
            String username = txtUsername.getText();
            String password = new String(txtPassword.getPassword());

            if (DatabaseConnection.isMock()) {
                if ("admin".equals(username) && "admin123".equals(password)) {
                    authenticated = true;
                    dispose();
                } else {
                    JOptionPane.showMessageDialog(this, "Identifiants incorrects", "Erreur", JOptionPane.ERROR_MESSAGE);
                    txtPassword.setText("");
                }
                return;
            }

            try (Connection conn = DatabaseConnection.getConnection();
                 PreparedStatement ps = conn.prepareStatement(
                         "SELECT * FROM admin WHERE username = ? AND password = ?"
                 )) {

                ps.setString(1, username);
                ps.setString(2, password);

                ResultSet rs = ps.executeQuery();

                if (rs.next()) {
                    authenticated = true;
                    dispose();
                } else {
                    JOptionPane.showMessageDialog(this, "Identifiants incorrects", "Erreur", JOptionPane.ERROR_MESSAGE);
                    txtPassword.setText("");
                }

            } catch (Exception ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(this, "Erreur de connexion: " + ex.getMessage(), "Erreur", JOptionPane.ERROR_MESSAGE);
            }
        });

        btnCancel.addActionListener(e -> System.exit(0));
    }

    private void styleLoginField(JComponent field) {
        field.setBackground(new Color(75, 55, 40));  // marron très foncé
        if (field instanceof JTextField) {
            ((JTextField) field).setForeground(UITheme.LOGIN_PAPER);
            ((JTextField) field).setCaretColor(UITheme.LOGIN_PAPER);
            ((JTextField) field).setFont(UITheme.BODY_FONT);
            ((JTextField) field).setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(UITheme.LOGIN_ACCENT, 1),
                BorderFactory.createEmptyBorder(8, 10, 8, 10)
            ));
        } else if (field instanceof JPasswordField) {
            ((JPasswordField) field).setForeground(UITheme.LOGIN_PAPER);
            ((JPasswordField) field).setCaretColor(UITheme.LOGIN_PAPER);
            ((JPasswordField) field).setFont(UITheme.BODY_FONT);
            ((JPasswordField) field).setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(UITheme.LOGIN_ACCENT, 1),
                BorderFactory.createEmptyBorder(8, 10, 8, 10)
            ));
        }
    }

    private void styleLoginButton(JButton button, Color baseColor) {
        button.setBackground(baseColor);
        button.setForeground(UITheme.LOGIN_PAPER);
        button.setFont(UITheme.BUTTON_FONT);
        button.setBorderPainted(false);
        button.setFocusPainted(false);
        button.setContentAreaFilled(true);
        button.setOpaque(true);
        button.setMargin(new Insets(12, 20, 12, 20));

        button.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent e) {
                button.setBackground(brighten(baseColor, 1.15f));
                button.setCursor(new Cursor(Cursor.HAND_CURSOR));
            }
            public void mouseExited(java.awt.event.MouseEvent e) {
                button.setBackground(baseColor);
            }
            public void mousePressed(java.awt.event.MouseEvent e) {
                button.setBackground(darken(baseColor, 0.85f));
            }
            public void mouseReleased(java.awt.event.MouseEvent e) {
                button.setBackground(brighten(baseColor, 1.15f));
            }
        });
    }

    private Color brighten(Color color, float factor) {
        int r = (int) Math.min(255, color.getRed() * factor);
        int g = (int) Math.min(255, color.getGreen() * factor);
        int b = (int) Math.min(255, color.getBlue() * factor);
        return new Color(r, g, b);
    }

    private Color darken(Color color, float factor) {
        int r = (int) (color.getRed() * factor);
        int g = (int) (color.getGreen() * factor);
        int b = (int) (color.getBlue() * factor);
        return new Color(r, g, b);
    }

    public boolean isAuthenticated() {
        return authenticated;
    }
}