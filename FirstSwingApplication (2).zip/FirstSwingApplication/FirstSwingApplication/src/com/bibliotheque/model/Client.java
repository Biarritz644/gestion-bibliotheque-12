package com.bibliotheque.model;

public class Client {

    private int id;
    private String nom;
    private int age;
    private String sexe;

    public Client() {}

    public Client(int id, String nom, int age, String sexe) {
        this.id = id;
        this.nom = nom;
        this.age = age;
        this.sexe = sexe;
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getNom() { return nom; }
    public void setNom(String nom) { this.nom = nom; }

    public int getAge() { return age; }
    public void setAge(int age) { this.age = age; }

    public String getSexe() { return sexe; }
    public void setSexe(String sexe) { this.sexe = sexe; }
}
