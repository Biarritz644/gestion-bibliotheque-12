package com.bibliotheque.model;

import java.time.LocalDate;

public class Emprunt {

    private int id;
    private Livre livre;
    private Client client;
    private LocalDate dateEmprunt;
    private LocalDate dateRetourPrevu;
    private LocalDate dateRetourReel;
    private String statut;
    private long amende;

    public Emprunt(){}

    public Emprunt(int id, Livre livre, Client client,
                   LocalDate dateEmprunt,
                   LocalDate dateRetourPrevu,
                   LocalDate dateRetourReel,
                   String statut,
                   long amende) {

        this.id = id;
        this.livre = livre;
        this.client = client;
        this.dateEmprunt = dateEmprunt;
        this.dateRetourPrevu = dateRetourPrevu;
        this.dateRetourReel = dateRetourReel;
        this.statut = statut;
        this.amende = amende;
    }

    public int getId() { return id; }

    public Livre getLivre() { return livre; }

    public Client getClient() { return client; }

    public LocalDate getDateEmprunt() { return dateEmprunt; }

    public LocalDate getDateRetourPrevu() { return dateRetourPrevu; }

    public LocalDate getDateRetourReel() { return dateRetourReel; }

    public String getStatut() { return statut; }

    public long getAmende() { return amende; }
}