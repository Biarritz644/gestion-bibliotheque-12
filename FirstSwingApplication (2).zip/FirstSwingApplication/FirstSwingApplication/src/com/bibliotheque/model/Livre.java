package com.bibliotheque.model;

public class Livre {

    private int id;
    private String titre;
    private String auteur;
    private int anneeEdition;
    private int quantite;

    private boolean disponible;

    public Livre() {}

    public Livre(int id, String titre, String auteur, int anneeEdition,int quantite) {
        this.id = id;
        this.titre = titre;
        this.auteur = auteur;
        this.anneeEdition = anneeEdition;
        this.quantite = quantite;
        this.disponible = quantite > 0;
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getTitre() { return titre; }
    public void setTitre(String titre) { this.titre = titre; }

    public String getAuteur() { return auteur; }
    public void setAuteur(String auteur) { this.auteur = auteur; }

    public int getAnneeEdition() { return anneeEdition; }
    public void setAnneeEdition(int anneeEdition) { this.anneeEdition = anneeEdition; }
    
    public int getQuantite() { return quantite; }
    public void setQuantite(int quantite) {
        this.quantite = quantite;
        this.disponible = quantite > 0;
    }

    public boolean isDisponible() { return disponible; }
}
