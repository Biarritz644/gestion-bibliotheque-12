package com.bibliotheque.util;

import com.bibliotheque.model.Client;
import com.bibliotheque.model.Emprunt;
import com.bibliotheque.model.Livre;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * DatabaseConnection: simple wrapper that provides either a real JDBC connection
 * (if drivers available and MOCK==false) or an in-memory mock data store used
 * for quick UI testing without external JDBC drivers.
 */
public class DatabaseConnection {

    // When true use light in-memory mock stores (no external drivers required)
    public static final boolean MOCK = true;

    private static final String URL = "jdbc:sqlite:bibliotheque.db";

    // --- Mock in-memory stores ---
    private static final List<Livre> livres = Collections.synchronizedList(new ArrayList<>());
    private static final List<Client> clients = Collections.synchronizedList(new ArrayList<>());
    private static final List<Emprunt> emprunts = Collections.synchronizedList(new ArrayList<>());

    private static final AtomicInteger livreId = new AtomicInteger(0);
    private static final AtomicInteger clientId = new AtomicInteger(0);
    private static final AtomicInteger empruntId = new AtomicInteger(0);

    static {
        if (!MOCK) {
            try {
                Class.forName("org.sqlite.JDBC");
            } catch (ClassNotFoundException e) {
                try {
                    Class.forName("org.h2.Driver");
                } catch (ClassNotFoundException ex) {
                    System.err.println("Aucun driver de base de données disponible!");
                }
            }
        } else {
            // quelques données d'exemple pour tests UI
            initMockData();
        }
    }

    private static void initMockData() {
        // clients
        clients.add(new Client(clientId.incrementAndGet(), "Alice Dupont", 30, "F"));
        clients.add(new Client(clientId.incrementAndGet(), "Jean Martin", 45, "M"));

        // livres
        livres.add(new Livre(livreId.incrementAndGet(), "Le Petit Prince", "Antoine de Saint-Exupéry", 1943, 3));
        livres.add(new Livre(livreId.incrementAndGet(), "1984", "George Orwell", 1949, 2));
        livres.add(new Livre(livreId.incrementAndGet(), "Clean Code", "Robert C. Martin", 2008, 1));

        // emprunt example
        emprunts.add(new Emprunt(empruntId.incrementAndGet(), livres.get(0), clients.get(0), LocalDate.now().minusDays(2), LocalDate.now().plusWeeks(3), null, "EN_COURS", 0L));
    }

    public static boolean isMock() { return MOCK; }

    // --- Mock helpers (Livre) ---
    public static synchronized List<Livre> mockGetAllLivres() {
        return new ArrayList<>(livres);
    }

    public static synchronized Livre mockGetLivreById(int id) {
        return livres.stream().filter(l -> l.getId() == id).findFirst().orElse(null);
    }

    public static synchronized void mockAddLivre(Livre l) {
        int id = livreId.incrementAndGet();
        l.setId(id);
        livres.add(l);
    }

    public static synchronized void mockModifierLivre(Livre l) {
        for (int i = 0; i < livres.size(); i++) {
            if (livres.get(i).getId() == l.getId()) {
                livres.set(i, l);
                return;
            }
        }
    }

    public static synchronized void mockSupprimerLivre(int id) {
        livres.removeIf(l -> l.getId() == id);
    }

    // --- Mock helpers (Client) ---
    public static synchronized List<Client> mockGetAllClients() {
        return new ArrayList<>(clients);
    }

    public static synchronized Client mockGetClientById(int id) {
        return clients.stream().filter(c -> c.getId() == id).findFirst().orElse(null);
    }

    public static synchronized void mockAddClient(Client c) {
        int id = clientId.incrementAndGet();
        c.setId(id);
        clients.add(c);
    }

    public static synchronized void mockModifierClient(Client c) {
        for (int i = 0; i < clients.size(); i++) {
            if (clients.get(i).getId() == c.getId()) {
                clients.set(i, c);
                return;
            }
        }
    }

    public static synchronized void mockSupprimerClient(int id) {
        clients.removeIf(c -> c.getId() == id);
    }

    // --- Mock helpers (Emprunt) ---
    public static synchronized List<Emprunt> mockGetAllEmprunts() {
        return new ArrayList<>(emprunts);
    }

    public static synchronized Emprunt mockGetEmpruntById(int id) {
        return emprunts.stream().filter(e -> e.getId() == id).findFirst().orElse(null);
    }

    public static synchronized void mockAddEmprunt(Emprunt e) {
        int id = empruntId.incrementAndGet();
        // set id via reflection-like approach (model has no setter), recreate
        Emprunt copy = new Emprunt(id, e.getLivre(), e.getClient(), e.getDateEmprunt(), e.getDateRetourPrevu(), e.getDateRetourReel(), e.getStatut(), e.getAmende());
        emprunts.add(copy);
    }

    public static synchronized void mockModifierEmprunt(Emprunt e) {
        for (int i = 0; i < emprunts.size(); i++) {
            if (emprunts.get(i).getId() == e.getId()) {
                emprunts.set(i, e);
                return;
            }
        }
    }

    public static synchronized void mockSupprimerEmprunt(int id) {
        emprunts.removeIf(ev -> ev.getId() == id);
    }

    // --- Real connection fallback ---
    public static Connection getConnection() throws SQLException {
        if (MOCK) {
            throw new SQLException("Mock mode: pas de connexion JDBC. Utilisez les helpers mockGet*/mockAdd*.");
        }

        try {
            return DriverManager.getConnection(URL);
        } catch (SQLException e) {
            return DriverManager.getConnection("jdbc:h2:mem:bibliotheque");
        }
    }
}
