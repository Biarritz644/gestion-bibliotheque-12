package com.bibliotheque.dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.time.LocalDate;

import com.bibliotheque.model.Client;
import com.bibliotheque.model.Livre;
import com.bibliotheque.service.EmpruntService;
import com.bibliotheque.model.Emprunt;
import com.bibliotheque.util.DatabaseConnection;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class EmpruntDAO {
	public void ajouterEmprunt(int clientId, int livreId) throws Exception {

	ClientDAO clientDAO = new ClientDAO();
	LivreDAO livreDAO = new LivreDAO();

	Client client = clientDAO.getClientById(clientId);
	Livre livre = livreDAO.getLivreById(livreId);

	if(client == null)
		throw new Exception("Client introuvable");

	if(livre == null)
		throw new Exception("Livre introuvable");

	if(livre.getQuantite() <= 0)
		throw new Exception("Stock insuffisant");

	LocalDate today = LocalDate.now();
	LocalDate retourPrevu = today.plusWeeks(3);

	if (DatabaseConnection.isMock()) {
		Emprunt e = new Emprunt(0, livre, client, today, retourPrevu, null, "EN_COURS", 0L);
		DatabaseConnection.mockAddEmprunt(e);
		// diminuer stock
		livre.setQuantite(livre.getQuantite() - 1);
		livreDAO.modifierLivre(livre);
		return;
	}

	String sql = """
		INSERT INTO emprunt
		(client_id, livre_id, date_emprunt, date_retour_prevu, statut, amende)
		VALUES (?, ?, ?, ?, ?, ?)
	""";

	try(Connection conn = DatabaseConnection.getConnection();
		PreparedStatement ps = conn.prepareStatement(sql)) {

		ps.setInt(1, clientId);
		ps.setInt(2, livreId);
		ps.setString(3, today.toString());
		ps.setString(4, retourPrevu.toString());
		ps.setString(5, "EN_COURS");
		ps.setLong(6, 0);

		ps.executeUpdate();
	}

	// DIMINUER STOCK
	livre.setQuantite(livre.getQuantite() - 1);
	livreDAO.modifierLivre(livre);
	}
	
	public void retournerLivre(int empruntId) throws Exception {

	Emprunt emprunt = getEmpruntById(empruntId);

	if(emprunt == null)
		throw new Exception("Emprunt introuvable");

	LocalDate today = LocalDate.now();

	EmpruntService service = new EmpruntService();

	long amende = service.calculerAmende(
			emprunt.getDateRetourPrevu(),
			today
	);

	String statut = amende > 0 ? "EN_LITIGE" : "TERMINE";

	if (DatabaseConnection.isMock()) {
		Emprunt e = new Emprunt(emprunt.getId(), emprunt.getLivre(), emprunt.getClient(), emprunt.getDateEmprunt(), emprunt.getDateRetourPrevu(), today, statut, amende);
		DatabaseConnection.mockModifierEmprunt(e);
		LivreDAO livreDAO = new LivreDAO();
		Livre livre = emprunt.getLivre();
		livre.setQuantite(livre.getQuantite() + 1);
		livreDAO.modifierLivre(livre);
		return;
	}

	String sql = """
		UPDATE emprunt
		SET date_retour_reel = ?, statut = ?, amende = ?
		WHERE id = ?
	""";

	try(Connection conn = DatabaseConnection.getConnection();
		PreparedStatement ps = conn.prepareStatement(sql)) {

		ps.setString(1, today.toString());
		ps.setString(2, statut);
		ps.setLong(3, amende);
		ps.setInt(4, empruntId);

		ps.executeUpdate();
	}

	// AUGMENTER STOCK
	LivreDAO livreDAO = new LivreDAO();
	Livre livre = emprunt.getLivre();
	livre.setQuantite(livre.getQuantite() + 1);
	livreDAO.modifierLivre(livre);
	}
	
	public Emprunt getEmpruntById(int id) throws Exception {

	if (DatabaseConnection.isMock()) {
		return DatabaseConnection.mockGetEmpruntById(id);
	}

	String sql = "SELECT * FROM emprunt WHERE id = ?";

	try(Connection conn = DatabaseConnection.getConnection();
		PreparedStatement ps = conn.prepareStatement(sql)) {

		ps.setInt(1, id);

		try(ResultSet rs = ps.executeQuery()) {

			if(rs.next()) {

				ClientDAO clientDAO = new ClientDAO();
				LivreDAO livreDAO = new LivreDAO();

				Client client = clientDAO.getClientById(rs.getInt("client_id"));
				Livre livre = livreDAO.getLivreById(rs.getInt("livre_id"));

				return new Emprunt(
						rs.getInt("id"),
						livre,
						client,
						LocalDate.parse(rs.getString("date_emprunt")),
						LocalDate.parse(rs.getString("date_retour_prevu")),
						rs.getString("date_retour_reel") == null
								? null
								: LocalDate.parse(rs.getString("date_retour_reel")),
						rs.getString("statut"),
						rs.getLong("amende")
				);
			}
		}
	}

	return null;
	}
	
	public List<Emprunt> getAllEmprunts() throws Exception {

	if (DatabaseConnection.isMock()) {
		return DatabaseConnection.mockGetAllEmprunts();
	}

	List<Emprunt> emprunts = new ArrayList<>();

	String sql = "SELECT * FROM emprunt";

	try(Connection conn = DatabaseConnection.getConnection();
		Statement stmt = conn.createStatement();
		ResultSet rs = stmt.executeQuery(sql)) {

		ClientDAO clientDAO = new ClientDAO();
		LivreDAO livreDAO = new LivreDAO();

		while(rs.next()) {

			Client client = clientDAO.getClientById(rs.getInt("client_id"));
			Livre livre = livreDAO.getLivreById(rs.getInt("livre_id"));

			Emprunt e = new Emprunt(
					rs.getInt("id"),
					livre,
					client,
					LocalDate.parse(rs.getString("date_emprunt")),
					LocalDate.parse(rs.getString("date_retour_prevu")),
					rs.getString("date_retour_reel") == null
							? null
							: LocalDate.parse(rs.getString("date_retour_reel")),
					rs.getString("statut"),
					rs.getLong("amende")
			);

			emprunts.add(e);
		}
	}

	return emprunts;
	}
	
	public void supprimerEmprunt(int empruntId) throws Exception {
	Emprunt emprunt = getEmpruntById(empruntId);

	if(emprunt == null)
		throw new Exception("Emprunt introuvable");

	// Si encore en cours → remettre stock
	if(emprunt.getStatut().equals("EN_COURS")) {

		LivreDAO livreDAO = new LivreDAO();
		Livre livre = emprunt.getLivre();
		livre.setQuantite(livre.getQuantite() + 1);
		livreDAO.modifierLivre(livre);
	}

	if (DatabaseConnection.isMock()) {
		DatabaseConnection.mockSupprimerEmprunt(empruntId);
		return;
	}

	String sql = "DELETE FROM emprunt WHERE id = ?";

	try(Connection conn = DatabaseConnection.getConnection();
		PreparedStatement ps = conn.prepareStatement(sql)) {

		ps.setInt(1, empruntId);
		ps.executeUpdate();
	}
	}
	public void modifierDateRetourReel(int empruntId, LocalDate nouvelleDate) throws Exception {

	    Emprunt emprunt = getEmpruntById(empruntId);

	    if(emprunt == null)
	        throw new Exception("Emprunt introuvable");

	    EmpruntService service = new EmpruntService();

	    long amende = service.calculerAmende(
	            emprunt.getDateRetourPrevu(),
	            nouvelleDate
	    );

	    String statut = amende > 0 ? "EN_LITIGE" : "TERMINE";

	    String sql = """
	        UPDATE emprunt
	        SET date_retour_reel = ?, statut = ?, amende = ?
	        WHERE id = ?
	    """;

	    try(Connection conn = DatabaseConnection.getConnection();
	        PreparedStatement ps = conn.prepareStatement(sql)) {

	        ps.setString(1, nouvelleDate.toString());
	        ps.setString(2, statut);
	        ps.setLong(3, amende);
	        ps.setInt(4, empruntId);

	        ps.executeUpdate();
	    }
	}
	
	public void modifierEmprunt(Emprunt e) throws Exception {

	Emprunt ancien = getEmpruntById(e.getId());

	if(ancien == null)
		throw new Exception("Emprunt introuvable");

	ClientDAO clientDAO = new ClientDAO();
	LivreDAO livreDAO = new LivreDAO();

	Client nouveauClient = clientDAO.getClientById(e.getClient().getId());
	Livre nouveauLivre = livreDAO.getLivreById(e.getLivre().getId());

	if(nouveauClient == null)
		throw new Exception("Client invalide");

	if(nouveauLivre == null)
		throw new Exception("Livre invalide");

	// ===== GESTION STOCK SI LIVRE CHANGE =====
	if(ancien.getLivre().getId() != nouveauLivre.getId()) {

		// remettre ancien livre
		Livre ancienLivre = ancien.getLivre();
		ancienLivre.setQuantite(ancienLivre.getQuantite() + 1);
		livreDAO.modifierLivre(ancienLivre);

		// retirer nouveau livre
		if(nouveauLivre.getQuantite() <= 0)
			throw new Exception("Stock insuffisant pour le nouveau livre");

		nouveauLivre.setQuantite(nouveauLivre.getQuantite() - 1);
		livreDAO.modifierLivre(nouveauLivre);
	}

	// ===== RECALCUL AMENDE =====
	EmpruntService service = new EmpruntService();

	long amende = 0;
	String statut = "EN_COURS";

	if(e.getDateRetourReel() != null) {

		amende = service.calculerAmende(
				e.getDateRetourPrevu(),
				e.getDateRetourReel()
		);

		statut = amende > 0 ? "EN_LITIGE" : "TERMINE";
	}

	if (DatabaseConnection.isMock()) {
		Emprunt copy = new Emprunt(e.getId(), nouveauLivre, nouveauClient, e.getDateEmprunt(), e.getDateRetourPrevu(), e.getDateRetourReel(), statut, amende);
		DatabaseConnection.mockModifierEmprunt(copy);
		return;
	}

	String sql = """
		UPDATE emprunt
		SET client_id = ?,
			livre_id = ?,
			date_emprunt = ?,
			date_retour_prevu = ?,
			date_retour_reel = ?,
			statut = ?,
			amende = ?
		WHERE id = ?
	""";

	try(Connection conn = DatabaseConnection.getConnection();
		PreparedStatement ps = conn.prepareStatement(sql)) {

		ps.setInt(1, nouveauClient.getId());
		ps.setInt(2, nouveauLivre.getId());
		ps.setString(3, e.getDateEmprunt().toString());
		ps.setString(4, e.getDateRetourPrevu().toString());

		if(e.getDateRetourReel() != null)
			ps.setString(5, e.getDateRetourReel().toString());
		else
			ps.setNull(5, Types.VARCHAR);

		ps.setString(6, statut);
		ps.setLong(7, amende);
		ps.setInt(8, e.getId());

		ps.executeUpdate();
	}
	}
}
