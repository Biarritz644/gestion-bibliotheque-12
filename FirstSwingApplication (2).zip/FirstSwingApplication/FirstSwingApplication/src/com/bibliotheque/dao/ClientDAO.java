package com.bibliotheque.dao;

import com.bibliotheque.model.Client;
import com.bibliotheque.util.DatabaseConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ClientDAO {

    public void ajouterClient(Client client) throws SQLException {
        if (DatabaseConnection.isMock()) {
            DatabaseConnection.mockAddClient(client);
            return;
        }

        String sql = "INSERT INTO client(nom,age,sexe) VALUES(?,?,?)";

        try(Connection conn = DatabaseConnection.getConnection();
            PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, client.getNom());
            ps.setInt(2, client.getAge());
            ps.setString(3, client.getSexe());

            ps.executeUpdate();
        }
    }

    public void modifierClient(Client client) throws SQLException {
        if (DatabaseConnection.isMock()) {
            DatabaseConnection.mockModifierClient(client);
            return;
        }

        String sql = """
            UPDATE client
            SET nom = ?, age = ?, sexe = ?
            WHERE id = ?
        """;

        try(Connection conn = DatabaseConnection.getConnection();
            PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, client.getNom());
            ps.setInt(2, client.getAge());
            ps.setString(3, client.getSexe());
            ps.setInt(4, client.getId());

            ps.executeUpdate();
        }
    }

    public void supprimerClient(int id) throws SQLException {
        if (DatabaseConnection.isMock()) {
            DatabaseConnection.mockSupprimerClient(id);
            return;
        }

        String sql = "DELETE FROM client WHERE id = ?";

        try(Connection conn = DatabaseConnection.getConnection();
            PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, id);
            ps.executeUpdate();
        }
    }

    public List<Client> getAllClients() throws SQLException {
        if (DatabaseConnection.isMock()) {
            return DatabaseConnection.mockGetAllClients();
        }

        List<Client> clients = new ArrayList<>();

        String sql = "SELECT * FROM client";

        try(Connection conn = DatabaseConnection.getConnection();
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(sql)) {

            while(rs.next()){
                clients.add(new Client(
                        rs.getInt("id"),
                        rs.getString("nom"),
                        rs.getInt("age"),
                        rs.getString("sexe")
                ));
            }
        }

        return clients;
    }
    public Client getClientById(int id) throws SQLException {
        if (DatabaseConnection.isMock()) {
            return DatabaseConnection.mockGetClientById(id);
        }

        String sql = "SELECT * FROM client WHERE id = ?";

        try(Connection conn = DatabaseConnection.getConnection();
            PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, id);

            try(ResultSet rs = ps.executeQuery()) {

                if(rs.next()) {
                    return new Client(
                            rs.getInt("id"),
                            rs.getString("nom"),
                            rs.getInt("age"),
                            rs.getString("sexe")
                    );
                }
            }
        }

        return null;
    }
}
