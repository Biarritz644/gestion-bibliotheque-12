package com.bibliotheque.dao;

import com.bibliotheque.model.Livre;

import com.bibliotheque.util.DatabaseConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class LivreDAO {

    public void ajouterLivre(Livre livre) throws SQLException {
        if (DatabaseConnection.isMock()) {
            DatabaseConnection.mockAddLivre(livre);
            return;
        }

        String sql = "INSERT INTO livre(titre,auteur,anneeEdition,quantite,disponible) VALUES(?,?,?,?,?)";

        try(Connection conn = DatabaseConnection.getConnection();
            PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, livre.getTitre());
            ps.setString(2, livre.getAuteur());
            ps.setInt(3, livre.getAnneeEdition());
            ps.setInt(4, livre.getQuantite());
            ps.setInt(5, livre.isDisponible() ? 1 : 0);

            ps.executeUpdate();
        }
    }
    public void supprimerLivre(int id) throws SQLException {
        if (DatabaseConnection.isMock()) {
            DatabaseConnection.mockSupprimerLivre(id);
            return;
        }

        String sql = "DELETE FROM livre WHERE id = ?";

        try(Connection conn = DatabaseConnection.getConnection();
            PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, id);
            ps.executeUpdate();
        }
    }
    public void modifierLivre(Livre livre) throws SQLException {
        if (DatabaseConnection.isMock()) {
            DatabaseConnection.mockModifierLivre(livre);
            return;
        }

        String sql = """
            UPDATE livre 
            SET titre = ?, auteur = ?, anneeEdition = ?,quantite = ?, disponible = ?
            WHERE id = ?
        """;

        try(Connection conn = DatabaseConnection.getConnection();
            PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, livre.getTitre());
            ps.setString(2, livre.getAuteur());
            ps.setInt(3, livre.getAnneeEdition());
            ps.setInt(4, livre.getQuantite());
            ps.setInt(5, livre.isDisponible() ? 1 : 0);
            
            ps.setInt(6, livre.getId());

            ps.executeUpdate();
        }
    }



    public List<Livre> getAllLivres() throws SQLException {
        if (DatabaseConnection.isMock()) {
            return DatabaseConnection.mockGetAllLivres();
        }

        List<Livre> livres = new ArrayList<>();

        String sql = "SELECT * FROM livre";

        try(Connection conn = DatabaseConnection.getConnection();
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(sql)) {

            while(rs.next()){
                livres.add(new Livre(
                        rs.getInt("id"),
                        rs.getString("titre"),
                        rs.getString("auteur"),
                        rs.getInt("anneeEdition"),
                        rs.getInt("quantite")
                ));
            }
        }

        return livres;
    }
    public Livre getLivreById(int id) throws SQLException {
        if (DatabaseConnection.isMock()) {
            return DatabaseConnection.mockGetLivreById(id);
        }

        String sql = "SELECT * FROM livre WHERE id = ?";

        try(Connection conn = DatabaseConnection.getConnection();
            PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, id);

            try(ResultSet rs = ps.executeQuery()) {

                if(rs.next()) {
                    return new Livre(
                            rs.getInt("id"),
                            rs.getString("titre"),
                            rs.getString("auteur"),
                            rs.getInt("anneeEdition"),
                            rs.getInt("quantite")
                    );
                }
            }
        }

        return null;
    }
}
