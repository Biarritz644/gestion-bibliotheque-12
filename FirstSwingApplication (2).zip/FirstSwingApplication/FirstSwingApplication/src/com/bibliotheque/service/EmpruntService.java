package com.bibliotheque.service;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

public class EmpruntService {

    private static final int AMENDE_PAR_JOUR = 2000;

    public long calculerAmende(LocalDate retourPrevu, LocalDate retourReel){

        if(retourReel.isAfter(retourPrevu)){

            long jours = ChronoUnit.DAYS.between(retourPrevu, retourReel);
            return jours * AMENDE_PAR_JOUR;
        }

        return 0;
    }
}
