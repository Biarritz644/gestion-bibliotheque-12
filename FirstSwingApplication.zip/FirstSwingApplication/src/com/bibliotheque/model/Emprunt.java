package com.bibliotheque.model;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.Objects;

public class Emprunt {

    private int id;
    private Livre livre;
    private Client client;
    private LocalDate dateEmprunt;
    private LocalDate dateRetourPrevu;
    private LocalDate dateRetourReel;

    public Emprunt() {}

    public Emprunt(int id, Livre livre, Client client,
                   LocalDate dateEmprunt,
                   LocalDate dateRetourPrevu,
                   LocalDate dateRetourReel) {

        this.id = id;
        this.livre = livre;
        this.client = client;
        this.dateEmprunt = dateEmprunt;
        this.dateRetourPrevu = dateRetourPrevu;
        this.dateRetourReel = dateRetourReel;
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public Livre getLivre() { return livre; }
    public void setLivre(Livre livre) { this.livre = livre; }

    public Client getClient() { return client; }
    public void setClient(Client client) { this.client = client; }

    public LocalDate getDateEmprunt() { return dateEmprunt; }
    public void setDateEmprunt(LocalDate dateEmprunt) { this.dateEmprunt = dateEmprunt; }

    public LocalDate getDateRetourPrevu() { return dateRetourPrevu; }
    public void setDateRetourPrevu(LocalDate dateRetourPrevu) { this.dateRetourPrevu = dateRetourPrevu; }

    public LocalDate getDateRetourReel() { return dateRetourReel; }
    public void setDateRetourReel(LocalDate dateRetourReel) { this.dateRetourReel = dateRetourReel; }

    public boolean estRendu() { return dateRetourReel != null; }

    public boolean estEnRetard() {
        if (dateRetourPrevu == null) return false;
        LocalDate ref = (dateRetourReel != null) ? dateRetourReel : LocalDate.now();
        return ref.isAfter(dateRetourPrevu);
    }

    public long getNombreJoursEmprunt() {
        if (dateEmprunt == null) return 0;
        LocalDate fin = (dateRetourReel != null) ? dateRetourReel : LocalDate.now();
        return ChronoUnit.DAYS.between(dateEmprunt, fin);
    }

    public double calculerAmende(double tarifParJour) {
        if (!estEnRetard() || dateRetourPrevu == null) return 0.0;
        LocalDate fin = (dateRetourReel != null) ? dateRetourReel : LocalDate.now();
        long joursRetard = ChronoUnit.DAYS.between(dateRetourPrevu, fin);
        return Math.max(0, joursRetard) * tarifParJour;
    }

    @Override
    public String toString() {
        return "Emprunt#" + id + " (" + (livre != null ? livre.getTitre() : "?") + ")";
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Emprunt)) return false;
        Emprunt emprunt = (Emprunt) o;
        return id == emprunt.id;
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }
}
