package com.bibliotheque.util;

/**
 * Centralise les paramètres de connexion MySQL.
 * Adapte DB_URL/USER/PASSWORD à ton environnement.
 */
public final class DbConfig {

    private DbConfig() {}

    // Exemple: base "biblio" sur localhost
    public static final String DB_URL =
            "jdbc:mysql://localhost:3306/biblio?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC";

    public static final String DB_USER = "root";
    public static final String DB_PASSWORD = "";
}
