package com.bibliotheque.ui;

import javax.swing.*;


import javax.swing.table.TableRowSorter;

import java.awt.*;
import java.util.Arrays;

import com.bibliotheque.dao.ClientDAO;
import com.bibliotheque.dao.LivreDAO;
import com.bibliotheque.ui.ClientTableModel;
import com.bibliotheque.model.Client;
import com.bibliotheque.model.Livre;

public class MainFrame extends JFrame {
	private JPanel createLivrePanel(){

	    JPanel panel = new JPanel(new BorderLayout());

	    LivreTableModel model = new LivreTableModel();

	    JTable table = new JTable(model);
	    //Barre de recherche
	    TableRowSorter<LivreTableModel> sorter = new TableRowSorter<>(model);
	    table.setRowSorter(sorter);

	    JTextField txtRecherche = new JTextField(20);
	    //recherche en temps reel
	    txtRecherche.getDocument().addDocumentListener(new javax.swing.event.DocumentListener() {

	        private void filter() {
	            String text = txtRecherche.getText();

	            if (text.trim().length() == 0) {
	                sorter.setRowFilter(null);
	            } else {
	            	//ici le regex permet d'ignorer les majuscules/min--> le texte ce que l'user tape et le 1 et 2 , c'est l'ordre dans la tab
	                sorter.setRowFilter(RowFilter.regexFilter("(?i)" + text, 1, 2));
	            }
	        }

	        @Override
	        public void insertUpdate(javax.swing.event.DocumentEvent e) {
	            filter();
	        }

	        @Override
	        public void removeUpdate(javax.swing.event.DocumentEvent e) {
	            filter();
	        }

	        @Override
	        public void changedUpdate(javax.swing.event.DocumentEvent e) {
	            filter();
	        }
	    });



	    JScrollPane scrollPane = new JScrollPane(table);

	    JPanel topPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
	    topPanel.add(new JLabel("Rechercher : "));
	    topPanel.add(txtRecherche);

	    panel.add(topPanel, BorderLayout.NORTH);
	    panel.add(scrollPane, BorderLayout.CENTER);

	    
	    LivreDAO dao = new LivreDAO();

	    try {
	        model.setLivres(dao.getAllLivres());
	    } catch (Exception e) {
	        e.printStackTrace();
	    }
	    JButton btnAjouter = new JButton("Ajouter");
	    JButton btnSupprimer = new JButton("Supprimer");
	    JButton btnModifier = new JButton("Modifier");
	    


	    JPanel buttonPanel = new JPanel();
	    buttonPanel.add(btnAjouter);
	    buttonPanel.add(btnSupprimer);
	    buttonPanel.add(btnModifier);
	    

	    panel.add(buttonPanel, BorderLayout.SOUTH);
	    
	 //  POUR BOUTON AJOUTER LIVRE
	    btnAjouter.addActionListener(e -> {

	        LivreFormDialog dialog = new LivreFormDialog(this, null);
	        dialog.setVisible(true);

	        if(dialog.isConfirmed()){
	            try {
	                dao.ajouterLivre(dialog.getLivre());
	                model.setLivres(dao.getAllLivres());
	            } catch (Exception ex) {
	                ex.printStackTrace();
	            }
	        }
	    });

	    //  POUR BOUTON SUPPRIMER LIVRE
	    btnSupprimer.addActionListener(e -> {

	        int selectedRow = table.getSelectedRow();

	        if(selectedRow != -1){

	            int confirm = JOptionPane.showConfirmDialog(
	                    this,
	                    "Voulez-vous vraiment supprimer ce livre ?",
	                    "Confirmation",
	                    JOptionPane.YES_NO_OPTION
	            );

	            if(confirm == JOptionPane.YES_OPTION){

	                int id = (int) model.getValueAt(selectedRow, 0);

	                try {
	                    dao.supprimerLivre(id);
	                    model.setLivres(dao.getAllLivres());
	                } catch (Exception ex) {
	                    ex.printStackTrace();
	                }
	            }
	        }
	    });
        //POUR MODIFIER
	    btnModifier.addActionListener(e -> {

	        int selectedRow = table.getSelectedRow();

	        if(selectedRow != -1){

	            int id = (int) model.getValueAt(selectedRow, 0);
	            String titre = (String) model.getValueAt(selectedRow, 1);
	            String auteur = (String) model.getValueAt(selectedRow, 2);
	            int annee = (int) model.getValueAt(selectedRow, 3);
	            int quantite = (int) model.getValueAt(selectedRow, 4);

	            Livre livre = new Livre(id, titre, auteur, annee, quantite);

	            LivreFormDialog dialog = new LivreFormDialog(this, livre);
	            dialog.setVisible(true);

	            if(dialog.isConfirmed()){
	                try {
	                    dao.modifierLivre(dialog.getLivre());
	                    model.setLivres(dao.getAllLivres());
	                } catch (Exception ex) {
	                    ex.printStackTrace();
	                }
	            }
	        }
	    });




	    return panel;
	}

	
	private JPanel createClientPanel(){

	    JPanel panel = new JPanel(new BorderLayout());

	    ClientTableModel model = new ClientTableModel();
	    JTable table = new JTable(model);

	    // ===== SORTER (important pour la recherche) =====
	    TableRowSorter<ClientTableModel> sorter = new TableRowSorter<>(model);
	    table.setRowSorter(sorter);

	    // ===== BARRE DE RECHERCHE =====
	    JTextField txtRecherche = new JTextField(20);

	    txtRecherche.getDocument().addDocumentListener(new javax.swing.event.DocumentListener() {

	        private void filter() {
	            String text = txtRecherche.getText();

	            if (text.trim().isEmpty()) {
	                sorter.setRowFilter(null);
	            } else {
	                sorter.setRowFilter(RowFilter.regexFilter("(?i)" + text));
	            }
	        }

	        public void insertUpdate(javax.swing.event.DocumentEvent e) { filter(); }
	        public void removeUpdate(javax.swing.event.DocumentEvent e) { filter(); }
	        public void changedUpdate(javax.swing.event.DocumentEvent e) { filter(); }
	    });

	    JPanel topPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
	    topPanel.add(new JLabel("Rechercher : "));
	    topPanel.add(txtRecherche);

	    panel.add(topPanel, BorderLayout.NORTH);

	    JScrollPane scrollPane = new JScrollPane(table);
	    panel.add(scrollPane, BorderLayout.CENTER);

	    // ===== DAO =====
	    ClientDAO dao = new ClientDAO();

	    try {
	        model.setClients(dao.getAllClients());
	    } catch (Exception e) {
	        e.printStackTrace();
	    }

	    // ===== BOUTONS =====
	    JButton btnAjouter = new JButton("Ajouter");
	    JButton btnSupprimer = new JButton("Supprimer");
	    JButton btnModifier = new JButton("Modifier");

	    JPanel buttonPanel = new JPanel();
	    buttonPanel.add(btnAjouter);
	    buttonPanel.add(btnSupprimer);
	    buttonPanel.add(btnModifier);

	    panel.add(buttonPanel, BorderLayout.SOUTH);

	    // =============================
	    // AJOUTER CLIENT
	    // =============================
	    btnAjouter.addActionListener(e -> {

	        ClientFormDialog dialog = new ClientFormDialog(this, null);
	        dialog.setVisible(true);

	        if(dialog.isConfirmed()){
	            try {
	                dao.ajouterClient(dialog.getClient());
	                model.setClients(dao.getAllClients());
	            } catch (Exception ex) {
	                ex.printStackTrace();
	            }
	        }
	    });

	    // =============================
	    // SUPPRIMER CLIENT
	    // =============================
	    btnSupprimer.addActionListener(e -> {

	        int selectedRow = table.getSelectedRow();

	        if(selectedRow != -1){

	            int modelRow = table.convertRowIndexToModel(selectedRow);

	            int confirm = JOptionPane.showConfirmDialog(
	                    this,
	                    "Voulez-vous vraiment supprimer ce Lecteur ?",
	                    "Confirmation",
	                    JOptionPane.YES_NO_OPTION
	            );

	            if(confirm == JOptionPane.YES_OPTION){

	                int id = (int) model.getValueAt(modelRow, 0);

	                try {
	                    dao.supprimerClient(id);
	                    model.setClients(dao.getAllClients());
	                } catch (Exception ex) {
	                    ex.printStackTrace();
	                }
	            }
	        }
	    });

	    // =============================
	    // MODIFIER CLIENT
	    // =============================
	    btnModifier.addActionListener(e -> {

	        int selectedRow = table.getSelectedRow();

	        if(selectedRow != -1){

	            int modelRow = table.convertRowIndexToModel(selectedRow);

	            int id = (int) model.getValueAt(modelRow, 0);
	            String nom = (String) model.getValueAt(modelRow, 1);
	            int age = (int) model.getValueAt(modelRow, 2);
	            String sexe = (String) model.getValueAt(modelRow, 3);

	            Client client = new Client(id, nom, age, sexe);

	            ClientFormDialog dialog = new ClientFormDialog(this, client);
	            dialog.setVisible(true);

	            if(dialog.isConfirmed()){
	                try {
	                    dao.modifierClient(dialog.getClient());
	                    model.setClients(dao.getAllClients());
	                } catch (Exception ex) {
	                    ex.printStackTrace();
	                }
	            }
	        }
	    });

	    return panel;
	}


    public MainFrame(){

        setTitle("Gestion Bibliothèque");
        setSize(900,600);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);

        JTabbedPane tabs = new JTabbedPane();

        tabs.add("Livres", createLivrePanel());

        tabs.add("Clients", createClientPanel());

        tabs.add("Emprunts", new JPanel());

        add(tabs);
    }

    public static void main(String[] args) {

        // ⚠️ MySQL: crée d'abord la base/tables via le fichier sql_schema_mysql.sql (fourni dans le projet).

        SwingUtilities.invokeLater(() -> {
    	        new MainFrame().setVisible(true);
    	    });
    }
}
