package com.bibliotheque.ui;

import com.bibliotheque.model.Client;

import javax.swing.*;
import java.awt.*;

public class ClientFormDialog extends JDialog {

    /**
	 * 
	 */
	private static final long serialVersionUID = -3426018041311635280L;
	/**
	 * 
	 */
	
	private JTextField txtNom = new JTextField(20);
    private JTextField txtAge = new JTextField(5);
    private JComboBox<String> cbSexe = new JComboBox<>(new String[]{"Homme","Femme"});

    private boolean confirmed = false;
    private Client client;

    public ClientFormDialog(JFrame parent, Client client) {
        super(parent, true);

        this.client = client;

        setTitle(client == null ? "Ajouter Client" : "Modifier Client");

        setLayout(new BorderLayout());

        JPanel form = new JPanel(new GridLayout(3,2,10,10));

        form.add(new JLabel("Nom:"));
        form.add(txtNom);

        form.add(new JLabel("Age:"));
        form.add(txtAge);

        form.add(new JLabel("Sexe:"));
        form.add(cbSexe);

        add(form, BorderLayout.CENTER);

        JButton btnOk = new JButton("Valider");
        JButton btnCancel = new JButton("Annuler");

        JPanel buttons = new JPanel();
        buttons.add(btnOk);
        buttons.add(btnCancel);

        add(buttons, BorderLayout.SOUTH);

        if(client != null){
            txtNom.setText(client.getNom());
            txtAge.setText(String.valueOf(client.getAge()));
            cbSexe.setSelectedItem(client.getSexe());
        }

        btnOk.addActionListener(e -> {
            confirmed = true;
            dispose();
        });

        btnCancel.addActionListener(e -> dispose());

        pack();
        setLocationRelativeTo(parent);
    }

    public boolean isConfirmed(){
        return confirmed;
    }

    public Client getClient(){

        String nom = txtNom.getText();
        int age = Integer.parseInt(txtAge.getText());
        String sexe = cbSexe.getSelectedItem().toString();

        if(client == null){
            return new Client(0, nom, age, sexe);
        } else {
            return new Client(client.getId(), nom, age, sexe);
        }
    }
}
