package com.bibliotheque.service;

import com.bibliotheque.dao.LivreDAO;
import com.bibliotheque.model.Livre;

import java.sql.SQLException;
import java.util.List;

public class LivreService {

    private final LivreDAO livreDAO;

    public LivreService() {
        this.livreDAO = new LivreDAO();
    }

    public LivreService(LivreDAO livreDAO) {
        this.livreDAO = livreDAO;
    }

    public int ajouterLivre(Livre livre) throws SQLException {
        if (livre == null) throw new IllegalArgumentException("Livre null");
        if (livre.getTitre() == null || livre.getTitre().trim().isEmpty())
            throw new IllegalArgumentException("Titre obligatoire");
        if (livre.getAuteur() == null || livre.getAuteur().trim().isEmpty())
            throw new IllegalArgumentException("Auteur obligatoire");
        if (livre.getQuantite() < 0) throw new IllegalArgumentException("Quantité invalide");

        return livreDAO.ajouterLivre(livre);
    }

    public boolean modifierLivre(Livre livre) throws SQLException {
        if (livre == null) throw new IllegalArgumentException("Livre null");
        if (livre.getId() <= 0) throw new IllegalArgumentException("ID invalide");
        if (livre.getQuantite() < 0) throw new IllegalArgumentException("Quantité invalide");
        return livreDAO.modifierLivre(livre);
    }

    public boolean supprimerLivre(int id) throws SQLException {
        if (id <= 0) throw new IllegalArgumentException("ID invalide");
        return livreDAO.supprimerLivre(id);
    }

    public Livre trouverParId(int id) throws SQLException {
        if (id <= 0) return null;
        return livreDAO.trouverParId(id);
    }

    public List<Livre> listerTous() throws SQLException {
        return livreDAO.getAllLivres();
    }

    public List<Livre> rechercher(String motCle) throws SQLException {
        return livreDAO.rechercher(motCle);
    }
}
