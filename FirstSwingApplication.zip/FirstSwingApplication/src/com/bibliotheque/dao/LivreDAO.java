package com.bibliotheque.dao;

import com.bibliotheque.model.Livre;
import com.bibliotheque.util.DatabaseConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class LivreDAO {

    public int ajouterLivre(Livre livre) throws SQLException {
        String sql = "INSERT INTO livre(titre,auteur,anneeEdition,quantite,disponible) VALUES(?,?,?,?,?)";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            ps.setString(1, livre.getTitre());
            ps.setString(2, livre.getAuteur());
            ps.setInt(3, livre.getAnneeEdition());
            ps.setInt(4, livre.getQuantite());
            ps.setBoolean(5, livre.isDisponible());

            ps.executeUpdate();

            try (ResultSet keys = ps.getGeneratedKeys()) {
                if (keys.next()) return keys.getInt(1);
            }
            return 0;
        }
    }

    public boolean supprimerLivre(int id) throws SQLException {
        String sql = "DELETE FROM livre WHERE id = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, id);
            return ps.executeUpdate() > 0;
        }
    }

    public boolean modifierLivre(Livre livre) throws SQLException {
        String sql = "UPDATE livre SET titre = ?, auteur = ?, anneeEdition = ?, quantite = ?, disponible = ? WHERE id = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, livre.getTitre());
            ps.setString(2, livre.getAuteur());
            ps.setInt(3, livre.getAnneeEdition());
            ps.setInt(4, livre.getQuantite());
            ps.setBoolean(5, livre.isDisponible());
            ps.setInt(6, livre.getId());

            return ps.executeUpdate() > 0;
        }
    }

    public Livre trouverParId(int id) throws SQLException {
        String sql = "SELECT * FROM livre WHERE id = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (!rs.next()) return null;
                Livre l = mapRow(rs);
                l.setDisponible(rs.getBoolean("disponible"));
                return l;
            }
        }
    }

    public List<Livre> getAllLivres() throws SQLException {
        List<Livre> livres = new ArrayList<>();
        String sql = "SELECT * FROM livre";

        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                Livre l = mapRow(rs);
                l.setDisponible(rs.getBoolean("disponible"));
                livres.add(l);
            }
        }
        return livres;
    }

    public List<Livre> rechercher(String motCle) throws SQLException {
        List<Livre> livres = new ArrayList<>();
        String sql = "SELECT * FROM livre WHERE titre LIKE ? OR auteur LIKE ?";

        String like = "%" + (motCle == null ? "" : motCle.trim()) + "%";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, like);
            ps.setString(2, like);

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Livre l = mapRow(rs);
                    l.setDisponible(rs.getBoolean("disponible"));
                    livres.add(l);
                }
            }
        }
        return livres;
    }

    public boolean setDisponible(int livreId, boolean disponible) throws SQLException {
        String sql = "UPDATE livre SET disponible = ? WHERE id = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setBoolean(1, disponible);
            ps.setInt(2, livreId);
            return ps.executeUpdate() > 0;
        }
    }

    /**
     * Met à jour la quantité d'un livre (transaction).
     * delta = -1 (emprunt) / +1 (retour).
     */
    public boolean updateQuantite(Connection conn, int livreId, int delta) throws SQLException {
        String sql = "UPDATE livre " +
                     "SET quantite = quantite + ?, " +
                     "    disponible = (quantite + ?) > 0 " +
                     "WHERE id = ? AND (quantite + ?) >= 0";

        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, delta);
            ps.setInt(2, delta);
            ps.setInt(3, livreId);
            ps.setInt(4, delta);
            return ps.executeUpdate() > 0;
        }
    }

    private Livre mapRow(ResultSet rs) throws SQLException {
        return new Livre(
                rs.getInt("id"),
                rs.getString("titre"),
                rs.getString("auteur"),
                rs.getInt("anneeEdition"),
                rs.getInt("quantite")
        );
    }
}
