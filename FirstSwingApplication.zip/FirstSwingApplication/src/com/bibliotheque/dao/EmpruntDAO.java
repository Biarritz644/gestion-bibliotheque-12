package com.bibliotheque.dao;

import com.bibliotheque.model.Client;
import com.bibliotheque.model.Emprunt;
import com.bibliotheque.model.Livre;
import com.bibliotheque.util.DatabaseConnection;

import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class EmpruntDAO {

    public int creerEmprunt(Connection conn, int livreId, int clientId,
                            LocalDate dateEmprunt, LocalDate dateRetourPrevu) throws SQLException {

        String sql = "INSERT INTO emprunt(livre_id, client_id, date_emprunt, date_retour_prevu, date_retour_reel) " +
                     "VALUES(?,?,?,?,NULL)";

        try (PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setInt(1, livreId);
            ps.setInt(2, clientId);
            ps.setDate(3, Date.valueOf(dateEmprunt));
            ps.setDate(4, Date.valueOf(dateRetourPrevu));
            ps.executeUpdate();

            try (ResultSet keys = ps.getGeneratedKeys()) {
                if (keys.next()) return keys.getInt(1);
            }
            return 0;
        }
    }

    public boolean enregistrerRetour(Connection conn, int empruntId, LocalDate dateRetourReel) throws SQLException {
        String sql = "UPDATE emprunt SET date_retour_reel = ? WHERE id = ? AND date_retour_reel IS NULL";

        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setDate(1, Date.valueOf(dateRetourReel));
            ps.setInt(2, empruntId);
            return ps.executeUpdate() > 0;
        }
    }

    public Emprunt trouverParId(int id) throws SQLException {
        String sql =
                "SELECT e.id as emprunt_id, e.date_emprunt, e.date_retour_prevu, e.date_retour_reel, " +
                "l.id as livre_id, l.titre, l.auteur, l.anneeEdition, l.quantite, l.disponible, " +
                "c.id as client_id, c.nom, c.age, c.sexe " +
                "FROM emprunt e " +
                "JOIN livre l ON l.id = e.livre_id " +
                "JOIN client c ON c.id = e.client_id " +
                "WHERE e.id = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (!rs.next()) return null;
                return mapRow(rs);
            }
        }
    }

    public List<Emprunt> listerEnCours() throws SQLException {
        String sql = baseSelect() + " WHERE e.date_retour_reel IS NULL ORDER BY e.date_emprunt DESC";
        return queryList(sql);
    }

    public List<Emprunt> listerTous() throws SQLException {
        String sql = baseSelect() + " ORDER BY e.date_emprunt DESC";
        return queryList(sql);
    }

    public List<Emprunt> listerEnRetard(LocalDate today) throws SQLException {
        String sql = baseSelect() + " WHERE e.date_retour_reel IS NULL AND e.date_retour_prevu < ? ORDER BY e.date_retour_prevu ASC";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setDate(1, Date.valueOf(today));
            try (ResultSet rs = ps.executeQuery()) {
                List<Emprunt> list = new ArrayList<>();
                while (rs.next()) list.add(mapRow(rs));
                return list;
            }
        }
    }

    private List<Emprunt> queryList(String sql) throws SQLException {
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            List<Emprunt> list = new ArrayList<>();
            while (rs.next()) list.add(mapRow(rs));
            return list;
        }
    }

    private String baseSelect() {
        return "SELECT e.id as emprunt_id, e.date_emprunt, e.date_retour_prevu, e.date_retour_reel, " +
               "l.id as livre_id, l.titre, l.auteur, l.anneeEdition, l.quantite, l.disponible, " +
               "c.id as client_id, c.nom, c.age, c.sexe " +
               "FROM emprunt e " +
               "JOIN livre l ON l.id = e.livre_id " +
               "JOIN client c ON c.id = e.client_id ";
    }

    private Emprunt mapRow(ResultSet rs) throws SQLException {
        Livre livre = new Livre(
                rs.getInt("livre_id"),
                rs.getString("titre"),
                rs.getString("auteur"),
                rs.getInt("anneeEdition"),
                rs.getInt("quantite")
        );
        livre.setDisponible(rs.getBoolean("disponible"));

        Client client = new Client(
                rs.getInt("client_id"),
                rs.getString("nom"),
                rs.getInt("age"),
                rs.getString("sexe")
        );

        LocalDate de = rs.getDate("date_emprunt").toLocalDate();
        LocalDate drp = rs.getDate("date_retour_prevu").toLocalDate();
        Date drr = rs.getDate("date_retour_reel");
        LocalDate drrLocal = (drr == null) ? null : drr.toLocalDate();

        return new Emprunt(rs.getInt("emprunt_id"), livre, client, de, drp, drrLocal);
    }
}
