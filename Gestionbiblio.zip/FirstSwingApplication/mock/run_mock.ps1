# run_mock.ps1 - lance json-server pour le mock API
$root = Split-Path -Parent $MyInvocation.MyCommand.Definition
Set-Location $root
if (-not (Get-Command json-server -ErrorAction SilentlyContinue)) {
    Write-Output "json-server n'est pas installé. Installez via: npm install -g json-server"
    exit 1
}
Write-Output "Lancement de json-server sur http://localhost:3000 (db.json)"
json-server --watch db.json --port 3000
