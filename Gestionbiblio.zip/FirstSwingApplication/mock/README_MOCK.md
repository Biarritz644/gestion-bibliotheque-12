Mock API with json-server

Prérequis:
- Node.js + npm
- Installer json-server globalement: `npm install -g json-server`

Lancer le mock (depuis le dossier `mock`):
```powershell
cd mock
json-server --watch db.json --port 3000
```
Endpoints disponibles (exemples):
- `GET http://localhost:3000/livres`
- `POST http://localhost:3000/livres`
- `GET http://localhost:3000/clients`
- `POST http://localhost:3000/emprunts`
- `POST http://localhost:3000/auth/login` (json-server ne gère pas d'authenfication réelle ; pour login vous pouvez faire une requête POST et vérifier côté frontend la correspondance avec la ressource `users`).

Exemples curl:
```bash
# Lister livres
curl http://localhost:3000/livres

# Créer emprunt
curl -X POST http://localhost:3000/emprunts -H "Content-Type: application/json" -d '{"livreId":1,"clientId":1,"dateEmprunt":"2026-02-20","dateRetourPrevu":"2026-03-06"}'
```

Notes:
- Les mots de passe sont en clair ici uniquement pour mock. En production, utilisez des mots de passe hashés et un endpoint d'authentification sécurisé.
- Si vous voulez des routes personnalisées (ex. `/auth/login`) il est possible d'ajouter un petit middleware ou d'utiliser `json-server-auth` ou un serveur mock plus riche.