# git_push_check.ps1
# Exécute des vérifications git et écrit la sortie dans git_push_check.txt
$root = 'c:\Users\andyk\Documents\FirstSwingApplication'
Set-Location $root
$out = Join-Path $root 'git_push_check.txt'
"--- START $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss') ---" | Out-File $out -Encoding utf8
"PWD: $PWD" | Out-File $out -Append -Encoding utf8
"--- git --version ---" | Out-File $out -Append -Encoding utf8
git --version 2>&1 | Out-File $out -Append -Encoding utf8
"--- git remote -v ---" | Out-File $out -Append -Encoding utf8
git remote -v 2>&1 | Out-File $out -Append -Encoding utf8
"--- git branch --show-current ---" | Out-File $out -Append -Encoding utf8
git branch --show-current 2>&1 | Out-File $out -Append -Encoding utf8
"--- git status --porcelain ---" | Out-File $out -Append -Encoding utf8
git status --porcelain 2>&1 | Out-File $out -Append -Encoding utf8
"--- git log --oneline -n 10 ---" | Out-File $out -Append -Encoding utf8
git log --oneline -n 10 2>&1 | Out-File $out -Append -Encoding utf8
"--- attempting git push -u origin feature/frontend-ui-zip ---" | Out-File $out -Append -Encoding utf8
git push -u origin feature/frontend-ui-zip 2>&1 | Out-File $out -Append -Encoding utf8
"--- END $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss') ---" | Out-File $out -Append -Encoding utf8
Write-Output "Wrote output to $out"