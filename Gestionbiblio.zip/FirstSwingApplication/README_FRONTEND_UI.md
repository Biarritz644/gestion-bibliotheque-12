README — Frontend UI pour FirstSwingApplication

Contenu
- Fichiers UI: src/com/bibliotheque/ui/**
- Archive fournie: frontend_ui.zip (contient le dossier UI et ce README)

But: Ce README explique comment compiler et lancer l'interface Swing localement.

Pré-requis
- JDK installé (11+ conseillé)
- (Optionnel) Driver MySQL: lib/mysql-connector-java-<version>.jar si vous voulez connecter une base MySQL

Compiler (PowerShell)
```powershell
Set-Location 'c:\Users\andyk\Documents\FirstSwingApplication'
# Compiler tous les fichiers Java et placer les .class dans bin
Get-ChildItem -Recurse -Filter *.java | ForEach-Object { $_.FullName } | %{ javac -d bin -sourcepath src $_ } 
# Ou pour compiler en une seule ligne (PowerShell):
# javac -d bin -sourcepath src (Get-ChildItem -Recurse -Filter *.java | ForEach-Object FullName)
```

Lancer l'application
```powershell
# Avec driver MySQL (si lib\mysql-connector-java-8.0.x.jar présent)
java -cp "bin;lib\mysql-connector-java-8.0.34.jar" com.bibliotheque.ui.MainFrame

# Sans driver (utilise le fallback en mémoire pour les utilisateurs)
java -cp "bin" com.bibliotheque.ui.MainFrame
```

Remarques
- L'utilisateur administrateur par défaut: `Jury` / `12345` (si la base est initialisée ou via fallback)
- Utilisateurs employés: `KIMANA`,`SHONGO`,`NZITA`,`NGUNZ`,`MAMBWE` — mot de passe: `1234`
- Si vous avez des erreurs liées au driver JDBC: ajoutez le .jar du connector MySQL dans `lib/` et relancez avec le `-cp` approprié.

Support
- Si vous voulez que j'ajoute ce README directement à `frontend_ui.zip` et régénère l'archive ici, je peux le faire (je suis en train de le faire maintenant).