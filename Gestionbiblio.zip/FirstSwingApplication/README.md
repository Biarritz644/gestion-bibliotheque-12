# FirstSwing - Frontend moderne

Ce dépôt contient l'application Java Swing "FirstSwing" (Gestion de bibliothèque).

Modifications apportées:

- Ajout d'un thème UI conforme au cahier des charges (`src/com/bibliotheque/ui/themes/Theme.java`).
- Composant `Sidebar` moderne (`src/com/bibliotheque/ui/components/Sidebar.java`).
- `DashboardPanel` (cartes statistiques, placeholder graphiques) (`src/com/bibliotheque/ui/dashboard/DashboardPanel.java`).
- `LoginPanel` (écran de connexion centré) (`src/com/bibliotheque/ui/auth/LoginPanel.java`).
- Intégration de la navigation par `CardLayout` dans `MainFrame`.

Compilation et exécution (Windows / PowerShell):

```powershell
# Compiler tout
javac -d bin (Get-ChildItem -Recurse -Filter *.java | ForEach-Object { $_.FullName })

# Lancer l'application
java -cp bin com.bibliotheque.ui.MainFrame
```

Push vers GitHub (exemple):

```bash
git checkout -b feat/ui/frontend-modernization
git add .
git commit -m "feat(ui): add modern frontend components and README"
git push -u origin feat/ui/frontend-modernization
```

Si vous voulez, je peux créer la branche et pousser les commits pour vous (requiert accès GitHub configuré localement).
