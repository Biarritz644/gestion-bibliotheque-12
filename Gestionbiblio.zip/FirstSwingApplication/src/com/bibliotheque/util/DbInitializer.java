package com.bibliotheque.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class DbInitializer {
    public static void main(String[] args) {
        try {
            String url = "jdbc:mysql://localhost:3306/?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC";
            String user = DbConfig.DB_USER;
            String pass = DbConfig.DB_PASSWORD;

            try (Connection c = DriverManager.getConnection(url, user, pass);
                 Statement st = c.createStatement()) {

                String sql = "CREATE DATABASE IF NOT EXISTS biblio CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci";
                st.executeUpdate(sql);
                System.out.println("Database 'biblio' ensured.");
            }
        } catch (Exception e) {
            System.err.println("Failed to ensure database: " + e.getMessage());
            e.printStackTrace();
            System.exit(1);
        }
    }
}
