package com.bibliotheque.util;

/**
 * Centralise les paramètres de connexion MySQL.
 * Adapte DB_URL/USER/PASSWORD à ton environnement.
 */
public final class DbConfig {
    private DbConfig() {}

    // Read from environment variables if provided, otherwise fallback to defaults
    private static final String DEFAULT_DB_URL =
            "jdbc:mysql://localhost:3306/biblio?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC";
    private static final String DEFAULT_DB_USER = "root";
    private static final String DEFAULT_DB_PASSWORD = "";

    public static final String DB_URL = System.getenv().getOrDefault("DB_URL", DEFAULT_DB_URL);
    public static final String DB_USER = System.getenv().getOrDefault("DB_USER", DEFAULT_DB_USER);
    public static final String DB_PASSWORD = System.getenv().getOrDefault("DB_PASSWORD", DEFAULT_DB_PASSWORD);
}
