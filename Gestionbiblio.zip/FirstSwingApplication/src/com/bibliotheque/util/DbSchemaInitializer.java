package com.bibliotheque.util;

import java.sql.Connection;
import java.sql.Statement;

public class DbSchemaInitializer {
    public static void ensureSchema() throws Exception {
        try (Connection c = DatabaseConnection.getConnection(); Statement st = c.createStatement()) {
            st.executeUpdate("CREATE TABLE IF NOT EXISTS livre (" +
                    "id INT AUTO_INCREMENT PRIMARY KEY, " +
                    "titre VARCHAR(255), " +
                    "auteur VARCHAR(255), " +
                    "anneeEdition INT, " +
                    "quantite INT, " +
                    "disponible BOOLEAN DEFAULT TRUE) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

            st.executeUpdate("CREATE TABLE IF NOT EXISTS client (" +
                    "id INT AUTO_INCREMENT PRIMARY KEY, " +
                    "nom VARCHAR(255), " +
                    "age INT, " +
                    "sexe VARCHAR(10)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

            st.executeUpdate("CREATE TABLE IF NOT EXISTS emprunt (" +
                    "id INT AUTO_INCREMENT PRIMARY KEY, " +
                    "livre_id INT NOT NULL, " +
                    "client_id INT NOT NULL, " +
                    "date_emprunt DATE NOT NULL, " +
                    "date_retour_prevu DATE NOT NULL, " +
                    "date_retour_reel DATE NULL, " +
                    "FOREIGN KEY (livre_id) REFERENCES livre(id), " +
                    "FOREIGN KEY (client_id) REFERENCES client(id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
        }
    }
}
