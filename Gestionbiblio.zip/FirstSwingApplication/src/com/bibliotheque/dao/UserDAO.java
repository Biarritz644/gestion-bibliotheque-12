package com.bibliotheque.dao;

import com.bibliotheque.model.User;
import com.bibliotheque.util.DatabaseConnection;
import com.bibliotheque.util.PasswordUtils;

import java.sql.*;
import java.util.Optional;
import java.util.Map;
import java.util.HashMap;

public class UserDAO {
    private boolean dbAvailable = true;
    private final Map<String, String> fallbackUsers = new HashMap<>();
    public void ensureDefaultUsers() throws SQLException {
        try (Connection c = DatabaseConnection.getConnection()) {
            try (Statement st = c.createStatement()) {
                st.execute("CREATE TABLE IF NOT EXISTS users ("+
                        "id INT AUTO_INCREMENT PRIMARY KEY, "+
                        "username VARCHAR(100) NOT NULL UNIQUE, "+
                        "password VARCHAR(255) NOT NULL, "+
                        "role VARCHAR(50) DEFAULT 'EMPLOYE'"+
                        ") ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
            }

            // Insert default users if not exist
            insertIfNotExists(c, "Jury", "12345", "ADMIN");
            insertIfNotExists(c, "KIMANA", "1234", "EMPLOYE");
            insertIfNotExists(c, "SHONGO", "1234", "EMPLOYE");
            insertIfNotExists(c, "NZITA", "1234", "EMPLOYE");
            insertIfNotExists(c, "NGUNZ", "1234", "EMPLOYE");
            insertIfNotExists(c, "MAMBWE", "1234", "EMPLOYE");
        } catch (SQLException ex) {
            // Si la DB n'est pas accessible (driver manquant, serveur indisponible),
            // basculer en fallback en mémoire pour permettre le test UI.
            dbAvailable = false;
            fallbackUsers.put("Jury", PasswordUtils.hashPassword("12345"));
            fallbackUsers.put("KIMANA", PasswordUtils.hashPassword("1234"));
            fallbackUsers.put("SHONGO", PasswordUtils.hashPassword("1234"));
            fallbackUsers.put("NZITA", PasswordUtils.hashPassword("1234"));
            fallbackUsers.put("NGUNZ", PasswordUtils.hashPassword("1234"));
            fallbackUsers.put("MAMBWE", PasswordUtils.hashPassword("1234"));
        }
    }

    private void insertIfNotExists(Connection c, String username, String password, String role) throws SQLException {
        String q = "SELECT id FROM users WHERE username = ?";
        try (PreparedStatement ps = c.prepareStatement(q)) {
            ps.setString(1, username);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return;
            }
        }

        String ins = "INSERT INTO users (username, password, role) VALUES (?,?,?)";
        try (PreparedStatement ps = c.prepareStatement(ins)) {
            ps.setString(1, username);
            ps.setString(2, PasswordUtils.hashPassword(password));
            ps.setString(3, role);
            ps.executeUpdate();
        }
    }

    public Optional<User> authenticate(String username, String password) throws SQLException {
        if (!dbAvailable) {
            String stored = fallbackUsers.get(username);
            if (stored != null && PasswordUtils.verifyPassword(password, stored)) {
                User u = new User(0, username, stored, username.equals("Jury") ? "ADMIN" : "EMPLOYE");
                return Optional.of(u);
            }
            return Optional.empty();
        }

        String q = "SELECT id, username, password, role FROM users WHERE username = ?";
        try (Connection c = DatabaseConnection.getConnection(); PreparedStatement ps = c.prepareStatement(q)) {
            ps.setString(1, username);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    String stored = rs.getString("password");
                    if (PasswordUtils.verifyPassword(password, stored)) {
                        User u = new User(rs.getInt("id"), rs.getString("username"), stored, rs.getString("role"));
                        return Optional.of(u);
                    }
                }
            }
        } catch (SQLException ex) {
            // en cas d'erreur, basculer en fallback
            dbAvailable = false;
            return authenticate(username, password);
        }
        return Optional.empty();
    }
}
