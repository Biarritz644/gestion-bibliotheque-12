package com.bibliotheque.service;

import com.bibliotheque.dao.ClientDAO;
import com.bibliotheque.dao.EmpruntDAO;
import com.bibliotheque.dao.LivreDAO;
import com.bibliotheque.model.Emprunt;
import com.bibliotheque.util.DatabaseConnection;

import java.sql.Connection;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.List;

public class EmpruntService {

    private final EmpruntDAO empruntDAO;
    private final LivreDAO livreDAO;
    private final ClientDAO clientDAO;

    public EmpruntService() {
        this.empruntDAO = new EmpruntDAO();
        this.livreDAO = new LivreDAO();
        this.clientDAO = new ClientDAO();
    }

    public double calculerAmende(Emprunt emprunt, double tarifParJour) {
        if (emprunt == null) return 0.0;
        return emprunt.calculerAmende(tarifParJour);
    }

    public int emprunterLivre(int livreId, int clientId, int dureeJours) throws SQLException {
        if (livreId <= 0 || clientId <= 0) throw new IllegalArgumentException("IDs invalides");
        if (dureeJours <= 0) dureeJours = 7;

        if (livreDAO.trouverParId(livreId) == null) throw new IllegalArgumentException("Livre introuvable");
        if (clientDAO.trouverParId(clientId) == null) throw new IllegalArgumentException("Client introuvable");

        LocalDate dateEmprunt = LocalDate.now();
        LocalDate dateRetourPrevu = dateEmprunt.plusDays(dureeJours);

        try (Connection conn = DatabaseConnection.getConnection()) {
            conn.setAutoCommit(false);
            try {
                boolean ok = livreDAO.updateQuantite(conn, livreId, -1);
                if (!ok) {
                    conn.rollback();
                    throw new IllegalStateException("Livre non disponible (quantité = 0)");
                }

                int empruntId = empruntDAO.creerEmprunt(conn, livreId, clientId, dateEmprunt, dateRetourPrevu);

                conn.commit();
                return empruntId;
            } catch (Exception ex) {
                conn.rollback();
                if (ex instanceof SQLException) throw (SQLException) ex;
                throw ex;
            } finally {
                conn.setAutoCommit(true);
            }
        }
    }

    public void retournerLivre(int empruntId) throws SQLException {
        if (empruntId <= 0) throw new IllegalArgumentException("ID emprunt invalide");

        Emprunt e = empruntDAO.trouverParId(empruntId);
        if (e == null) throw new IllegalArgumentException("Emprunt introuvable");
        if (e.estRendu()) throw new IllegalStateException("Déjà rendu");

        int livreId = e.getLivre().getId();
        LocalDate dateRetour = LocalDate.now();

        try (Connection conn = DatabaseConnection.getConnection()) {
            conn.setAutoCommit(false);
            try {
                boolean okRetour = empruntDAO.enregistrerRetour(conn, empruntId, dateRetour);
                if (!okRetour) {
                    conn.rollback();
                    throw new IllegalStateException("Impossible d'enregistrer le retour");
                }

                livreDAO.updateQuantite(conn, livreId, +1);
                conn.commit();
            } catch (Exception ex) {
                conn.rollback();
                if (ex instanceof SQLException) throw (SQLException) ex;
                throw ex;
            } finally {
                conn.setAutoCommit(true);
            }
        }
    }

    public List<Emprunt> listerEnCours() throws SQLException {
        return empruntDAO.listerEnCours();
    }

    public List<Emprunt> listerTous() throws SQLException {
        return empruntDAO.listerTous();
    }

    public List<Emprunt> listerEnRetard() throws SQLException {
        return empruntDAO.listerEnRetard(LocalDate.now());
    }
}
