package com.bibliotheque.service;

import com.bibliotheque.dao.ClientDAO;
import com.bibliotheque.model.Client;

import java.sql.SQLException;
import java.util.List;

public class ClientService {

    private final ClientDAO clientDAO;

    public ClientService() {
        this.clientDAO = new ClientDAO();
    }

    public ClientService(ClientDAO clientDAO) {
        this.clientDAO = clientDAO;
    }

    public int ajouterClient(Client client) throws SQLException {
        if (client == null) throw new IllegalArgumentException("Client null");
        if (!client.estValide()) throw new IllegalArgumentException("Nom obligatoire");
        return clientDAO.ajouterClient(client);
    }

    public boolean modifierClient(Client client) throws SQLException {
        if (client == null) throw new IllegalArgumentException("Client null");
        if (client.getId() <= 0) throw new IllegalArgumentException("ID invalide");
        if (!client.estValide()) throw new IllegalArgumentException("Nom obligatoire");
        return clientDAO.modifierClient(client);
    }

    public boolean supprimerClient(int id) throws SQLException {
        if (id <= 0) throw new IllegalArgumentException("ID invalide");
        return clientDAO.supprimerClient(id);
    }

    public Client trouverParId(int id) throws SQLException {
        if (id <= 0) return null;
        return clientDAO.trouverParId(id);
    }

    public List<Client> listerTous() throws SQLException {
        return clientDAO.getAllClients();
    }

    public List<Client> rechercher(String motCle) throws SQLException {
        return clientDAO.rechercher(motCle);
    }
}
