package com.bibliotheque.ui;

import com.bibliotheque.ui.auth.LoginDialog;

import javax.swing.*;

public class UiRunner {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            try {
                LoginDialog dlg = new LoginDialog(null);
                dlg.ensureDefaults();
                dlg.setVisible(true);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }
}
