package com.bibliotheque.ui.dashboard;

import com.bibliotheque.ui.themes.Theme;
import com.bibliotheque.ui.components.UIUtils;
import com.bibliotheque.util.DatabaseConnection;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.function.Supplier;

public class StatViewPanel extends JPanel {
    private final JLabel statLabel = new JLabel("0");
    private final Supplier<String> supplier;

    public StatViewPanel(String title, Color accent, Supplier<String> supplier, Runnable onBack) {
        this.supplier = supplier;
        setLayout(new BorderLayout(12,12));
        setBackground(Theme.BACKGROUND);
        setBorder(BorderFactory.createEmptyBorder(12,12,12,12));

        JLabel lbl = new JLabel(title);
        lbl.setFont(Theme.UI_FONT.deriveFont(Font.BOLD, 18f));
        lbl.setForeground(Theme.TEXT);

        statLabel.setFont(Theme.UI_FONT.deriveFont(Font.BOLD, 36f));
        statLabel.setForeground(accent);
        statLabel.setHorizontalAlignment(SwingConstants.CENTER);

        add(lbl, BorderLayout.NORTH);
        add(statLabel, BorderLayout.CENTER);

        JPanel actions = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        actions.setOpaque(false);

        JButton btnRefresh = new JButton("Raffraichir");
        UIUtils.styleButton(btnRefresh);
        JButton btnBack = new JButton("Retour");
        UIUtils.styleSecondaryButton(btnBack);

        btnRefresh.addActionListener((ActionEvent e) -> refresh());
        btnBack.addActionListener((ActionEvent e) -> onBack.run());

        actions.add(btnBack);
        actions.add(btnRefresh);

        add(actions, BorderLayout.SOUTH);

        refresh();
    }

    public void refresh() {
        try {
            String val = supplier.get();
            statLabel.setText(val);
        } catch (Exception ex) {
            statLabel.setText("N/A");
        }
    }
}
