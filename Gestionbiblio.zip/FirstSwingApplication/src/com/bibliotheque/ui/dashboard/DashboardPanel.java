package com.bibliotheque.ui.dashboard;

import com.bibliotheque.ui.themes.Theme;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import com.bibliotheque.util.DatabaseConnection;

public class DashboardPanel extends JPanel {
    private final DashboardNavigator navigator;

    public DashboardPanel() {
        this(null);
    }

    public DashboardPanel(DashboardNavigator navigator) {
        this.navigator = navigator;
        setLayout(new BorderLayout());
        setBackground(Theme.BACKGROUND);

        JPanel header = new JPanel(new BorderLayout());
        header.setOpaque(false);

        JLabel title = new JLabel("Tableau de bord");
        title.setFont(Theme.UI_FONT.deriveFont(Font.BOLD, 20f));
        title.setForeground(Theme.TEXT);
        header.add(title, BorderLayout.WEST);

        add(header, BorderLayout.NORTH);

        JPanel cards = new JPanel(new GridLayout(1, 3, 12, 12));
        cards.setOpaque(false);
        cards.setBorder(BorderFactory.createEmptyBorder(12,12,12,12));

        cards.add(createStatCard("Livres", getStats("Livres"), Theme.PRIMARY));
        cards.add(createStatCard("Clients", getStats("Clients"), Theme.SUCCESS));
        cards.add(createStatCard("Emprunts actifs", getStats("Emprunts actifs"), Theme.WARNING));

        add(cards, BorderLayout.CENTER);

        JPanel placeholder = new JPanel(new BorderLayout());
        placeholder.setOpaque(false);
        JLabel chartPlaceholder = new JLabel("[Graphiques JFreeChart ici]");
        chartPlaceholder.setHorizontalAlignment(SwingConstants.CENTER);
        chartPlaceholder.setForeground(Theme.TEXT);
        placeholder.add(chartPlaceholder, BorderLayout.CENTER);

        add(placeholder, BorderLayout.SOUTH);
    }

    private JPanel createStatCard(String label, String value, Color color) {
        JPanel p = new JPanel(new BorderLayout());
        p.setBackground(Color.WHITE);
        p.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(230,230,230)),
                BorderFactory.createEmptyBorder(12,12,12,12)));

        JLabel l = new JLabel(label);
        l.setForeground(Theme.TEXT);
        l.setFont(Theme.UI_FONT.deriveFont(12f));

        JLabel v = new JLabel(value);
        v.setForeground(color);
        v.setFont(Theme.UI_FONT.deriveFont(Font.BOLD, 24f));

        p.add(l, BorderLayout.NORTH);
        p.add(v, BorderLayout.CENTER);

        // Make card clickable to open a detailed view with Refresh and Retour
        p.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        p.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                if (navigator != null) {
                    navigator.showStat(label, color);
                } else {
                    openStatDialog(label, color);
                }
            }
        });

        return p;
    }

    private String getStats(String label) {
        try (Connection c = DatabaseConnection.getConnection()) {
            String q;
            switch (label) {
                case "Livres": q = "SELECT COUNT(*) FROM livre"; break;
                case "Clients": q = "SELECT COUNT(*) FROM client"; break;
                case "Emprunts actifs": q = "SELECT COUNT(*) FROM emprunt WHERE date_retour_reel IS NULL"; break;
                default: return "N/A";
            }
            try (PreparedStatement ps = c.prepareStatement(q); ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return String.valueOf(rs.getInt(1));
            }
        } catch (SQLException ex) {
            // DB unavailable or table missing: return placeholder
            return "N/A";
        }
        return "0";
    }

    private void openStatDialog(String label, Color accent) {
        JDialog d = new JDialog(SwingUtilities.getWindowAncestor(this), label, Dialog.ModalityType.APPLICATION_MODAL);
        JPanel content = new JPanel(new BorderLayout(12,12));
        content.setBorder(BorderFactory.createEmptyBorder(12,12,12,12));
        content.setBackground(Theme.BACKGROUND);

        JLabel title = new JLabel(label);
        title.setFont(Theme.UI_FONT.deriveFont(Font.BOLD, 18f));
        title.setForeground(Theme.TEXT);

        JLabel statLabel = new JLabel(getStats(label));
        statLabel.setFont(Theme.UI_FONT.deriveFont(Font.BOLD, 36f));
        statLabel.setForeground(accent);
        statLabel.setHorizontalAlignment(SwingConstants.CENTER);

        content.add(title, BorderLayout.NORTH);
        content.add(statLabel, BorderLayout.CENTER);

        JPanel actions = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        actions.setOpaque(false);

        JButton refresh = new JButton("Raffraichir");
        refresh.setBackground(Theme.PRIMARY);
        refresh.setForeground(Color.WHITE);
        refresh.setFocusPainted(false);

        JButton back = new JButton("Retour");
        back.setBackground(new Color(240,240,240));
        back.setForeground(Theme.TEXT);
        back.setFocusPainted(false);

        refresh.addActionListener(ev -> {
            statLabel.setText(getStats(label));
        });

        back.addActionListener(ev -> d.dispose());

        actions.add(back);
        actions.add(refresh);
        content.add(actions, BorderLayout.SOUTH);

        d.setContentPane(content);
        d.pack();
        d.setLocationRelativeTo(this);
        d.setVisible(true);
    }
}
