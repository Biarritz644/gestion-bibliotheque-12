package com.bibliotheque.ui.dashboard;

import java.awt.Color;

/**
 * Callback interface used by `DashboardPanel` to ask the container to show a detailed stat view.
 */
public interface DashboardNavigator {
    void showStat(String key, Color accent);
}
