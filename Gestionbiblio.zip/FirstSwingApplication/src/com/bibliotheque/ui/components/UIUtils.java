package com.bibliotheque.ui.components;

import com.bibliotheque.ui.themes.Theme;

import javax.swing.*;
import javax.swing.table.DefaultTableCellRenderer;
import java.awt.*;

public final class UIUtils {
    private UIUtils() {}

    public static void styleButton(JButton b) {
        b.setFocusPainted(false);
        b.setOpaque(true);
        b.setBackground(Theme.PRIMARY);
        b.setForeground(Color.WHITE);
        b.setFont(Theme.UI_FONT.deriveFont(13f));
        b.setBorder(new RoundedBorder(12, new Color(200,200,200,0)));
        b.setPreferredSize(new Dimension(160,40));
    }

    public static void styleSecondaryButton(JButton b) {
        b.setFocusPainted(false);
        b.setOpaque(true);
        b.setBackground(Color.WHITE);
        b.setForeground(Theme.TEXT);
        b.setFont(Theme.UI_FONT.deriveFont(13f));
        b.setBorder(new RoundedBorder(12, new Color(220,220,220)));
        b.setPreferredSize(new Dimension(160,40));
    }

    public static void styleTable(JTable table) {
        table.setRowHeight(28);
        table.setFont(Theme.UI_FONT);
        table.setSelectionBackground(Theme.PRIMARY);
        table.setSelectionForeground(Color.WHITE);

        // Header style
        JTableHeader header = table.getTableHeader();
        header.setBackground(Color.WHITE);
        header.setForeground(Theme.TEXT);
        header.setFont(Theme.UI_FONT.deriveFont(Font.BOLD));

        // Alternating row colors
        table.setDefaultRenderer(Object.class, new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
                Component c = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
                if (!isSelected) {
                    c.setBackground((row % 2 == 0) ? Color.WHITE : new Color(245,247,250));
                    c.setForeground(Theme.TEXT);
                }
                return c;
            }
        });
    }
}
