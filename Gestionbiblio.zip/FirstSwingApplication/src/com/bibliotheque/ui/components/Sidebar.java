package com.bibliotheque.ui.components;

import com.bibliotheque.ui.themes.Theme;

import javax.swing.*;
import java.awt.*;

public class Sidebar extends JPanel {
    private final JButton btnDashboard = createButton("Tableau de bord");
    private final JButton btnLivres = createButton("Livres");
    private final JButton btnClients = createButton("Clients");
    private final JButton btnEmprunts = createButton("Emprunts");
    private final JButton btnLogout = createButton("Déconnexion");
    private final JButton btnDarkMode = createButton("Mode sombre");

    public Sidebar() {
        setLayout(new GridBagLayout());
        setBackground(Theme.SIDEBAR);
        setPreferredSize(new Dimension(220, 0));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(10, 12, 10, 12);

        JLabel title = new JLabel("FirstSwing");
        title.setForeground(Color.WHITE);
        title.setFont(Theme.UI_FONT.deriveFont(Font.BOLD, 18f));
        gbc.gridy = 0;
        add(title, gbc);

        gbc.gridy = 1;
        add(Box.createVerticalStrut(8), gbc);


        // add with icons
        btnDashboard.setIcon(new CircleIcon(Theme.PRIMARY, 12));
        btnLivres.setIcon(new CircleIcon(Theme.SUCCESS, 12));
        btnClients.setIcon(new CircleIcon(Theme.WARNING, 12));
        btnEmprunts.setIcon(new CircleIcon(Theme.DANGER, 12));

        gbc.gridy = 2; add(btnDashboard, gbc);
        gbc.gridy = 3; add(btnLivres, gbc);
        gbc.gridy = 4; add(btnClients, gbc);
        gbc.gridy = 5; add(btnEmprunts, gbc);

        gbc.gridy = 6; add(Box.createVerticalGlue(), gbc);

        gbc.gridy = 7; add(btnDarkMode, gbc);
        gbc.gridy = 8; add(btnLogout, gbc);
    }

    private JButton createButton(String text) {
        JButton b = new JButton(text);
        b.setFocusPainted(false);
        b.setBackground(Theme.SIDEBAR);
        b.setForeground(Color.WHITE);
        b.setBorderPainted(false);
        b.setHorizontalAlignment(SwingConstants.LEFT);
        b.setFont(Theme.UI_FONT.deriveFont(13f));
        b.setCursor(new Cursor(Cursor.HAND_CURSOR));
        b.setOpaque(true);
        b.setPreferredSize(new Dimension(180, 38));
        b.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) { b.setBackground(Theme.PRIMARY); }
            public void mouseExited(java.awt.event.MouseEvent evt) { b.setBackground(Theme.SIDEBAR); }
        });
        b.setBorder(BorderFactory.createEmptyBorder(6,12,6,12));
        return b;
    }

    public void setActiveButton(JButton active) {
        for (Component c : getComponents()) {
            if (c instanceof JButton) {
                JButton btn = (JButton) c;
                if (btn == active) {
                    btn.setBackground(Theme.PRIMARY);
                    btn.setForeground(Color.WHITE);
                } else {
                    btn.setBackground(Theme.SIDEBAR);
                    btn.setForeground(Color.WHITE);
                }
            }
        }
    }

    public JButton getBtnDashboard() { return btnDashboard; }
    public JButton getBtnLivres() { return btnLivres; }
    public JButton getBtnClients() { return btnClients; }
    public JButton getBtnEmprunts() { return btnEmprunts; }
    public JButton getBtnLogout() { return btnLogout; }
    public JButton getBtnDarkMode() { return btnDarkMode; }
}
