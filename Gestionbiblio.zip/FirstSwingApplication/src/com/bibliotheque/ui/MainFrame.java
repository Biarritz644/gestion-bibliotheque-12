package com.bibliotheque.ui;

import javax.swing.*;
import javax.swing.table.TableRowSorter;

import java.awt.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashSet;
import java.util.Set;
import com.bibliotheque.dao.ClientDAO;
import com.bibliotheque.dao.LivreDAO;
import com.bibliotheque.ui.ClientTableModel;
import com.bibliotheque.model.Client;
import com.bibliotheque.model.Livre;
import com.bibliotheque.ui.components.Sidebar;
import com.bibliotheque.ui.dashboard.DashboardPanel;
import com.bibliotheque.ui.dashboard.DashboardNavigator;
import com.bibliotheque.ui.dashboard.StatViewPanel;
import com.bibliotheque.ui.themes.Theme;

public class MainFrame extends JFrame {
	private JPanel cardsPanel;
	private CardLayout cardLayout;
	private final Set<String> cardNames = new HashSet<>();
	private boolean darkMode = false;
	private JPanel createLivrePanel(){

	    JPanel panel = new JPanel(new BorderLayout());

	    LivreTableModel model = new LivreTableModel();

		JTable table = new JTable(model);
		com.bibliotheque.ui.components.UIUtils.styleTable(table);
		// Allow horizontal scrolling when columns overflow
		table.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
	    //Barre de recherche
	    TableRowSorter<LivreTableModel> sorter = new TableRowSorter<>(model);
	    table.setRowSorter(sorter);

	    JTextField txtRecherche = new JTextField(20);
	    //recherche en temps reel
	    txtRecherche.getDocument().addDocumentListener(new javax.swing.event.DocumentListener() {

	        private void filter() {
	            String text = txtRecherche.getText();

	            if (text.trim().length() == 0) {
	                sorter.setRowFilter(null);
	            } else {
	            	//ici le regex permet d'ignorer les majuscules/min--> le texte ce que l'user tape et le 1 et 2 , c'est l'ordre dans la tab
	                sorter.setRowFilter(RowFilter.regexFilter("(?i)" + text, 1, 2));
	            }
	        }

	        @Override
	        public void insertUpdate(javax.swing.event.DocumentEvent e) {
	            filter();
	        }

	        @Override
	        public void removeUpdate(javax.swing.event.DocumentEvent e) {
	            filter();
	        }

	        @Override
	        public void changedUpdate(javax.swing.event.DocumentEvent e) {
	            filter();
	        }
	    });



		JScrollPane scrollPane = new JScrollPane(table, JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED, JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		scrollPane.getViewport().setBackground(Theme.BACKGROUND);

	    JPanel topPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
	    topPanel.add(new JLabel("Rechercher : "));
	    topPanel.add(txtRecherche);

	    panel.add(topPanel, BorderLayout.NORTH);
	    panel.add(scrollPane, BorderLayout.CENTER);

	    
	    LivreDAO dao = new LivreDAO();

	    try {
	        model.setLivres(dao.getAllLivres());
	    } catch (Exception e) {
	        e.printStackTrace();
	    }
	    JButton btnAjouter = new JButton("Ajouter");
	    JButton btnSupprimer = new JButton("Supprimer");
	    JButton btnModifier = new JButton("Modifier");
	    


		JPanel buttonPanel = new JPanel();
		com.bibliotheque.ui.components.UIUtils.styleButton(btnAjouter);
		com.bibliotheque.ui.components.UIUtils.styleSecondaryButton(btnSupprimer);
		com.bibliotheque.ui.components.UIUtils.styleSecondaryButton(btnModifier);
		buttonPanel.add(btnAjouter);
		buttonPanel.add(btnSupprimer);
		buttonPanel.add(btnModifier);
	    

	    panel.add(buttonPanel, BorderLayout.SOUTH);
	    
	 //  POUR BOUTON AJOUTER LIVRE
	    btnAjouter.addActionListener(e -> {

	        LivreFormDialog dialog = new LivreFormDialog(this, null);
	        dialog.setVisible(true);

	        if(dialog.isConfirmed()){
	            try {
	                dao.ajouterLivre(dialog.getLivre());
	                model.setLivres(dao.getAllLivres());
	            } catch (Exception ex) {
	                ex.printStackTrace();
	            }
	        }
	    });

	    //  POUR BOUTON SUPPRIMER LIVRE
		btnSupprimer.addActionListener(e -> {

			int selectedRow = table.getSelectedRow();

			if(selectedRow != -1){

				int confirm = JOptionPane.showConfirmDialog(
						this,
						"Voulez-vous vraiment supprimer ce livre ?",
						"Confirmation",
						JOptionPane.YES_NO_OPTION
				);

				if(confirm == JOptionPane.YES_OPTION){

					int modelRow = table.convertRowIndexToModel(selectedRow);
					int id = (int) model.getValueAt(modelRow, 0);

					try {
						dao.supprimerLivre(id);
						model.setLivres(dao.getAllLivres());
					} catch (Exception ex) {
						ex.printStackTrace();
					}
				}
			}
		});
        //POUR MODIFIER
		btnModifier.addActionListener(e -> {

			int selectedRow = table.getSelectedRow();

			if(selectedRow != -1){

				int modelRow = table.convertRowIndexToModel(selectedRow);
				int id = (int) model.getValueAt(modelRow, 0);
				String titre = (String) model.getValueAt(modelRow, 1);
				String auteur = (String) model.getValueAt(modelRow, 2);
				int annee = (int) model.getValueAt(modelRow, 3);
				int quantite = (int) model.getValueAt(modelRow, 4);

				Livre livre = new Livre(id, titre, auteur, annee, quantite);

				LivreFormDialog dialog = new LivreFormDialog(this, livre);
				dialog.setVisible(true);

				if(dialog.isConfirmed()){
					try {
						dao.modifierLivre(dialog.getLivre());
						model.setLivres(dao.getAllLivres());
					} catch (Exception ex) {
						ex.printStackTrace();
					}
				}
			}
		});




	    return panel;
	}

	
	private JPanel createClientPanel(){

	    JPanel panel = new JPanel(new BorderLayout());

	    ClientTableModel model = new ClientTableModel();
		JTable table = new JTable(model);
		com.bibliotheque.ui.components.UIUtils.styleTable(table);
		// Allow horizontal scrolling when columns overflow
		table.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);

	    // ===== SORTER (important pour la recherche) =====
	    TableRowSorter<ClientTableModel> sorter = new TableRowSorter<>(model);
	    table.setRowSorter(sorter);

	    // ===== BARRE DE RECHERCHE =====
	    JTextField txtRecherche = new JTextField(20);

	    txtRecherche.getDocument().addDocumentListener(new javax.swing.event.DocumentListener() {

	        private void filter() {
	            String text = txtRecherche.getText();

	            if (text.trim().isEmpty()) {
	                sorter.setRowFilter(null);
	            } else {
	                sorter.setRowFilter(RowFilter.regexFilter("(?i)" + text));
	            }
	        }

	        public void insertUpdate(javax.swing.event.DocumentEvent e) { filter(); }
	        public void removeUpdate(javax.swing.event.DocumentEvent e) { filter(); }
	        public void changedUpdate(javax.swing.event.DocumentEvent e) { filter(); }
	    });

	    JPanel topPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
	    topPanel.add(new JLabel("Rechercher : "));
	    topPanel.add(txtRecherche);

	    panel.add(topPanel, BorderLayout.NORTH);

		JScrollPane scrollPane = new JScrollPane(table, JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED, JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		scrollPane.getViewport().setBackground(Theme.BACKGROUND);
	    panel.add(scrollPane, BorderLayout.CENTER);

	    // ===== DAO =====
	    ClientDAO dao = new ClientDAO();

	    try {
	        model.setClients(dao.getAllClients());
	    } catch (Exception e) {
	        e.printStackTrace();
	    }

	    // ===== BOUTONS =====
	    JButton btnAjouter = new JButton("Ajouter");
	    JButton btnSupprimer = new JButton("Supprimer");
	    JButton btnModifier = new JButton("Modifier");

		JPanel buttonPanel = new JPanel();
		com.bibliotheque.ui.components.UIUtils.styleButton(btnAjouter);
		com.bibliotheque.ui.components.UIUtils.styleSecondaryButton(btnSupprimer);
		com.bibliotheque.ui.components.UIUtils.styleSecondaryButton(btnModifier);
		buttonPanel.add(btnAjouter);
		buttonPanel.add(btnSupprimer);
		buttonPanel.add(btnModifier);

	    panel.add(buttonPanel, BorderLayout.SOUTH);

	    // =============================
	    // AJOUTER CLIENT
	    // =============================
	    btnAjouter.addActionListener(e -> {

	        ClientFormDialog dialog = new ClientFormDialog(this, null);
	        dialog.setVisible(true);

	        if(dialog.isConfirmed()){
	            try {
	                dao.ajouterClient(dialog.getClient());
	                model.setClients(dao.getAllClients());
	            } catch (Exception ex) {
	                ex.printStackTrace();
	            }
	        }
	    });

	    // =============================
	    // SUPPRIMER CLIENT
	    // =============================
	    btnSupprimer.addActionListener(e -> {

	        int selectedRow = table.getSelectedRow();

	        if(selectedRow != -1){

	            int modelRow = table.convertRowIndexToModel(selectedRow);

	            int confirm = JOptionPane.showConfirmDialog(
	                    this,
	                    "Voulez-vous vraiment supprimer ce Lecteur ?",
	                    "Confirmation",
	                    JOptionPane.YES_NO_OPTION
	            );

	            if(confirm == JOptionPane.YES_OPTION){

	                int id = (int) model.getValueAt(modelRow, 0);

	                try {
	                    dao.supprimerClient(id);
	                    model.setClients(dao.getAllClients());
	                } catch (Exception ex) {
	                    ex.printStackTrace();
	                }
	            }
	        }
	    });

	    // =============================
	    // MODIFIER CLIENT
	    // =============================
	    btnModifier.addActionListener(e -> {

	        int selectedRow = table.getSelectedRow();

	        if(selectedRow != -1){

	            int modelRow = table.convertRowIndexToModel(selectedRow);

	            int id = (int) model.getValueAt(modelRow, 0);
	            String nom = (String) model.getValueAt(modelRow, 1);
	            int age = (int) model.getValueAt(modelRow, 2);
	            String sexe = (String) model.getValueAt(modelRow, 3);

	            Client client = new Client(id, nom, age, sexe);

	            ClientFormDialog dialog = new ClientFormDialog(this, client);
	            dialog.setVisible(true);

	            if(dialog.isConfirmed()){
	                try {
	                    dao.modifierClient(dialog.getClient());
	                    model.setClients(dao.getAllClients());
	                } catch (Exception ex) {
	                    ex.printStackTrace();
	                }
	            }
	        }
	    });

	    return panel;
	}


    public MainFrame(){
		setTitle("Gestion Bibliothèque - FirstSwing");
		setSize(1100,700);
		setLocationRelativeTo(null);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		getContentPane().setBackground(Theme.BACKGROUND);

		Sidebar sidebar = new Sidebar();

		cardLayout = new CardLayout();
		cardsPanel = new JPanel(cardLayout);

		// Panels
		// Dashboard with navigator to open stat views in the CardLayout
		cardsPanel.add(new DashboardPanel(new DashboardNavigator() {
			@Override
			public void showStat(String key, java.awt.Color accent) {
				String id = "stat_" + key.replaceAll("\\s+", "_").toLowerCase();
				// Create supplier that queries DB for the requested stat
				// Create supplier that queries DB for the requested stat
				java.util.function.Supplier<String> supplier = () -> {
					try (Connection c = com.bibliotheque.util.DatabaseConnection.getConnection()) {
						String q;
						switch (key) {
							case "Livres": q = "SELECT COUNT(*) FROM livre"; break;
							case "Clients": q = "SELECT COUNT(*) FROM client"; break;
							case "Emprunts actifs": q = "SELECT COUNT(*) FROM emprunt WHERE date_retour_reel IS NULL"; break;
							default: return "N/A";
						}
						try (PreparedStatement ps = c.prepareStatement(q); ResultSet rs = ps.executeQuery()) {
							if (rs.next()) return String.valueOf(rs.getInt(1));
						}
					} catch (SQLException ex) {
						return "N/A";
					}
					return "0";
				};

				// Add panel under id if not present
				if (!hasCard(id)) {
					StatViewPanel sv = new StatViewPanel(key, accent, supplier, () -> showCard("dashboard"));
					cardsPanel.add(sv, id);
					cardNames.add(id);
				}
				showCard(id);
			}
		}), "dashboard"); cardNames.add("dashboard");
		cardsPanel.add(createLivrePanel(), "livres"); cardNames.add("livres");
		cardsPanel.add(createClientPanel(), "clients"); cardNames.add("clients");
		cardsPanel.add(new EmpruntPanel(this), "emprunts"); cardNames.add("emprunts");

		// Split pane with sidebar
		JSplitPane split = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, sidebar, cardsPanel);
		split.setDividerSize(1);
		split.setDividerLocation(220);
		split.setOneTouchExpandable(false);
		split.setBorder(null);

		add(split, BorderLayout.CENTER);

		// Navigation
		sidebar.getBtnDashboard().addActionListener(e -> { sidebar.setActiveButton(sidebar.getBtnDashboard()); showCard("dashboard"); });
		sidebar.getBtnLivres().addActionListener(e -> { sidebar.setActiveButton(sidebar.getBtnLivres()); showCard("livres"); });
		sidebar.getBtnClients().addActionListener(e -> { sidebar.setActiveButton(sidebar.getBtnClients()); showCard("clients"); });
		sidebar.getBtnEmprunts().addActionListener(e -> { sidebar.setActiveButton(sidebar.getBtnEmprunts()); showCard("emprunts"); });
		sidebar.getBtnDarkMode().addActionListener(e -> {
			darkMode = !darkMode;
			applyDarkMode(darkMode, sidebar, cardsPanel);
		});
		sidebar.getBtnLogout().addActionListener(e -> {
			int confirm = JOptionPane.showConfirmDialog(this, "Se déconnecter ?", "Déconnexion", JOptionPane.YES_NO_OPTION);
			if(confirm == JOptionPane.YES_OPTION) {
				dispose();
			}
		});

		// Default view
		sidebar.setActiveButton(sidebar.getBtnDashboard());
		showCard("dashboard");
    }

	private void showCard(String name){
		cardLayout.show(cardsPanel, name);
	}

	private boolean hasCard(String name) {
		return cardNames.contains(name);
	}

	private void applyDarkMode(boolean dark, Sidebar sidebar, JPanel cardsPanel) {
		Color bg = dark ? new Color(34,38,45) : Theme.BACKGROUND;
		Color sidebarColor = dark ? new Color(20,22,26) : Theme.SIDEBAR;
		Color text = dark ? Color.WHITE : Theme.TEXT;

		getContentPane().setBackground(bg);
		sidebar.setBackground(sidebarColor);
		for (Component c : sidebar.getComponents()) {
			if (c instanceof JButton) {
				JButton b = (JButton) c;
				b.setBackground(sidebarColor);
				b.setForeground(text);
			} else if (c instanceof JLabel) {
				c.setForeground(text);
			}
		}

		for (Component c : cardsPanel.getComponents()) {
			if (c instanceof JPanel) {
				c.setBackground(bg);
				for (Component cc : ((JPanel) c).getComponents()) {
					cc.setBackground(bg);
					cc.setForeground(text);
				}
			}
		}
		repaint();
	}

    public static void main(String[] args) {
		// ⚠️ MySQL: crée d'abord la base 'biblio' et assure que le serveur MySQL est disponible.
		SwingUtilities.invokeLater(() -> {
			try {
				// Préremplir les utilisateurs par défaut
				com.bibliotheque.dao.UserDAO udao = new com.bibliotheque.dao.UserDAO();
				udao.ensureDefaultUsers();

				// Afficher le dialogue de connexion
				com.bibliotheque.ui.auth.LoginDialog dlg = new com.bibliotheque.ui.auth.LoginDialog(null);
				dlg.setVisible(true);

				if (!dlg.isAuthenticated()) {
					// si l'utilisateur n'a pas réussi à se connecter, on quitte
					System.exit(0);
				}

				new MainFrame().setVisible(true);
			} catch (Exception e) {
				e.printStackTrace();
				JOptionPane.showMessageDialog(null, "Erreur initialisation: " + e.getMessage(), "Erreur", JOptionPane.ERROR_MESSAGE);
				System.exit(1);
			}
		});
    }
}
