package com.bibliotheque.ui.auth;

import com.bibliotheque.dao.UserDAO;
import com.bibliotheque.model.User;
import com.bibliotheque.ui.themes.Theme;

import javax.swing.*;
import java.awt.*;
import java.sql.SQLException;
import java.util.Optional;

public class LoginDialog extends JDialog {
    private final UserDAO userDAO = new UserDAO();
    private boolean authenticated = false;

    public LoginDialog(Frame owner) {
        super(owner, "Se connecter", true);
        setSize(480,320);
        setLocationRelativeTo(owner);
        setLayout(new BorderLayout());

        // Header with title and icon
        JPanel header = new JPanel(new FlowLayout(FlowLayout.CENTER));
        header.setBackground(Theme.BACKGROUND);
        JLabel title = new JLabel("BiBLIO");
        title.setFont(Theme.UI_FONT.deriveFont(Font.BOLD, 28f));
        title.setForeground(Theme.TEXT);
        // simple book icon using emoji as fallback
        JLabel icon = new JLabel("📚");
        icon.setFont(Theme.UI_FONT.deriveFont(28f));
        header.add(icon);
        header.add(Box.createHorizontalStrut(8));
        header.add(title);
        add(header, BorderLayout.NORTH);

        // Center with two buttons
        JPanel center = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 30));
        center.setBackground(Theme.BACKGROUND);

        JButton btnLogin = new JButton("SE CONNECTER");
        JButton btnRegister = new JButton("S'inscrire");

        stylePrimary(btnLogin);
        styleSecondary(btnRegister);

        center.add(btnLogin);
        center.add(btnRegister);

        add(center, BorderLayout.CENTER);

        // Login form panel hidden by default
        JPanel formPanel = new JPanel(new GridBagLayout());
        formPanel.setBackground(Theme.BACKGROUND);
        formPanel.setVisible(false);

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(6,6,6,6);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        JTextField txtUser = new JTextField(18);
        JPasswordField txtPass = new JPasswordField(18);
        JButton btnSubmit = new JButton("Connexion");

        gbc.gridx = 0; gbc.gridy = 0; formPanel.add(new JLabel("Nom d'utilisateur:"), gbc);
        gbc.gridx = 1; formPanel.add(txtUser, gbc);
        gbc.gridx = 0; gbc.gridy = 1; formPanel.add(new JLabel("Mot de passe:"), gbc);
        gbc.gridx = 1; formPanel.add(txtPass, gbc);
        gbc.gridx = 0; gbc.gridy = 2; gbc.gridwidth = 2; formPanel.add(btnSubmit, gbc);

        add(formPanel, BorderLayout.SOUTH);

        btnLogin.addActionListener(e -> {
            center.setVisible(false);
            formPanel.setVisible(true);
            pack();
            setSize(480,360);
        });

        btnRegister.addActionListener(e -> JOptionPane.showMessageDialog(this, "Fonction d'inscription non implémentée.", "Info", JOptionPane.INFORMATION_MESSAGE));

        btnSubmit.addActionListener(e -> {
            String user = txtUser.getText().trim();
            String pass = new String(txtPass.getPassword());
            try {
                Optional<User> u = userDAO.authenticate(user, pass);
                if (u.isPresent()) {
                    JOptionPane.showMessageDialog(this, "Bienvenue, " + u.get().getUsername() + " !", "Succès", JOptionPane.INFORMATION_MESSAGE);
                    authenticated = true;
                    dispose();
                } else {
                    JOptionPane.showMessageDialog(this, "Identifiants incorrects.", "Erreur", JOptionPane.ERROR_MESSAGE);
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(this, "Erreur DB: " + ex.getMessage(), "Erreur", JOptionPane.ERROR_MESSAGE);
            }
        });
    }

    private void stylePrimary(JButton b) {
        b.setBackground(Theme.PRIMARY);
        b.setForeground(Color.WHITE);
        b.setFont(Theme.UI_FONT.deriveFont(Font.BOLD, 14f));
        b.setPreferredSize(new Dimension(180,44));
        b.setFocusPainted(false);
    }

    private void styleSecondary(JButton b) {
        b.setBackground(Color.WHITE);
        b.setForeground(Theme.TEXT);
        b.setFont(Theme.UI_FONT.deriveFont(14f));
        b.setPreferredSize(new Dimension(180,44));
        b.setFocusPainted(false);
    }

    public void ensureDefaults() throws SQLException {
        userDAO.ensureDefaultUsers();
    }

    public boolean isAuthenticated() { return authenticated; }
}
