package com.bibliotheque.ui.auth;

import com.bibliotheque.ui.themes.Theme;

import javax.swing.*;
import java.awt.*;

public class LoginPanel extends JPanel {
    private final JTextField txtUser = new JTextField(20);
    private final JPasswordField txtPass = new JPasswordField(20);
    private final JButton btnLogin = new JButton("Se connecter");

    public LoginPanel() {
        setLayout(new GridBagLayout());
        setBackground(Theme.BACKGROUND);

        JPanel card = new JPanel(new GridBagLayout());
        card.setBackground(Color.WHITE);
        card.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(230,230,230)),
                BorderFactory.createEmptyBorder(20,20,20,20)));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(8,8,8,8);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        JLabel title = new JLabel("Connexion");
        title.setFont(Theme.UI_FONT.deriveFont(Font.BOLD, 18f));
        title.setForeground(Theme.TEXT);
        gbc.gridwidth = 2;
        gbc.gridy = 0;
        card.add(title, gbc);

        gbc.gridwidth = 1;
        gbc.gridy = 1;
        card.add(new JLabel("Nom d'utilisateur:"), gbc);
        gbc.gridx = 1;
        card.add(txtUser, gbc);

        gbc.gridx = 0;
        gbc.gridy = 2;
        card.add(new JLabel("Mot de passe:"), gbc);
        gbc.gridx = 1;
        card.add(txtPass, gbc);

        gbc.gridx = 0;
        gbc.gridy = 3;
        gbc.gridwidth = 2;
        btnLogin.setBackground(Theme.PRIMARY);
        btnLogin.setForeground(Color.WHITE);
        btnLogin.setFocusPainted(false);
        card.add(btnLogin, gbc);

        add(card);
    }

    public JButton getBtnLogin() { return btnLogin; }
    public String getUsername() { return txtUser.getText(); }
    public String getPassword() { return new String(txtPass.getPassword()); }
}
