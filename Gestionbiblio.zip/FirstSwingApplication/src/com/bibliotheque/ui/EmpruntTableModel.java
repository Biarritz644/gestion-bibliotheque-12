package com.bibliotheque.ui;

import com.bibliotheque.model.Emprunt;

import javax.swing.table.AbstractTableModel;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

public class EmpruntTableModel extends AbstractTableModel {

    private static final long serialVersionUID = 1L;

    private List<Emprunt> emprunts = new ArrayList<>();
    private final String[] columns = {"ID", "Livre", "Client", "Date emprunt", "Date retour prévu", "Date retour réel", "Statut"};
    private final DateTimeFormatter df = DateTimeFormatter.ofPattern("yyyy-MM-dd");

    public void setEmprunts(List<Emprunt> emprunts){
        this.emprunts = emprunts;
        fireTableDataChanged();
    }

    @Override
    public int getRowCount() { return emprunts.size(); }

    @Override
    public int getColumnCount() { return columns.length; }

    @Override
    public String getColumnName(int column) { return columns[column]; }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        Emprunt e = emprunts.get(rowIndex);
        switch(columnIndex) {
            case 0: return e.getId();
            case 1: return e.getLivre() != null ? e.getLivre().getTitre() : "-";
            case 2: return e.getClient() != null ? e.getClient().getNom() : "-";
            case 3: return e.getDateEmprunt() != null ? e.getDateEmprunt().format(df) : "-";
            case 4: return e.getDateRetourPrevu() != null ? e.getDateRetourPrevu().format(df) : "-";
            case 5: return e.getDateRetourReel() != null ? e.getDateRetourReel().format(df) : "-";
            case 6: return e.estRendu() ? "Rendu" : (e.estEnRetard() ? "En retard" : "En cours");
            default: return null;
        }
    }
}
