package com.bibliotheque.ui;

import com.bibliotheque.dao.EmpruntDAO;
import com.bibliotheque.dao.LivreDAO;
import com.bibliotheque.dao.ClientDAO;
import com.bibliotheque.model.Emprunt;
import com.bibliotheque.model.Livre;
import com.bibliotheque.model.Client;
import com.bibliotheque.ui.components.UIUtils;
import com.bibliotheque.ui.themes.Theme;

import javax.swing.*;
import javax.swing.table.TableRowSorter;
import java.awt.*;
import java.time.LocalDate;
import java.util.List;

public class EmpruntPanel extends JPanel {

    private final EmpruntTableModel model = new EmpruntTableModel();
    private final JTable table = new JTable(model);

    public EmpruntPanel(JFrame parent) {
        setLayout(new BorderLayout());
        setBackground(Theme.BACKGROUND);

        UIUtils.styleTable(table);
        table.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);

        TableRowSorter<EmpruntTableModel> sorter = new TableRowSorter<>(model);
        table.setRowSorter(sorter);

        JScrollPane sp = new JScrollPane(table, JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED, JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
        sp.getViewport().setBackground(Theme.BACKGROUND);
        add(sp, BorderLayout.CENTER);

        JPanel top = new JPanel(new FlowLayout(FlowLayout.LEFT));
        top.setOpaque(false);

        JButton btnCreate = new JButton("Nouvel emprunt");
        JButton btnReturn = new JButton("Enregistrer retour");
        JButton btnRefresh = new JButton("Raffraichir");

        UIUtils.styleButton(btnCreate);
        UIUtils.styleSecondaryButton(btnReturn);
        UIUtils.styleButton(btnRefresh);

        top.add(btnCreate);
        top.add(btnReturn);
        top.add(btnRefresh);

        add(top, BorderLayout.NORTH);

        EmpruntDAO dao = new EmpruntDAO();
        LivreDAO livreDao = new LivreDAO();
        ClientDAO clientDao = new ClientDAO();

        btnRefresh.addActionListener(e -> {
            try { model.setEmprunts(dao.listerTous()); } catch (Exception ex) { ex.printStackTrace(); }
        });

        btnCreate.addActionListener(e -> {
            try {
                List<Livre> livres = livreDao.getAllLivres();
                List<Client> clients = clientDao.getAllClients();

                JComboBox<Livre> livreBox = new JComboBox<>(livres.toArray(new Livre[0]));
                JComboBox<Client> clientBox = new JComboBox<>(clients.toArray(new Client[0]));

                JPanel form = new JPanel(new GridLayout(0,1,6,6));
                form.add(new JLabel("Livre")); form.add(livreBox);
                form.add(new JLabel("Client")); form.add(clientBox);
                form.add(new JLabel("Date emprunt"));
                JSpinner dateSpinner = new JSpinner(new SpinnerDateModel());
                form.add(dateSpinner);

                int ok = JOptionPane.showConfirmDialog(parent, form, "Nouvel emprunt", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
                if (ok == JOptionPane.OK_OPTION) {
                    Livre selectedLivre = (Livre) livreBox.getSelectedItem();
                    Client selectedClient = (Client) clientBox.getSelectedItem();
                    LocalDate now = LocalDate.now();
                    LocalDate retourPrev = now.plusWeeks(2);
                    try (java.sql.Connection conn = com.bibliotheque.util.DatabaseConnection.getConnection()) {
                        conn.setAutoCommit(false);
                        dao.creerEmprunt(conn, selectedLivre.getId(), selectedClient.getId(), now, retourPrev);
                        conn.commit();
                    }
                    btnRefresh.doClick();
                }
            } catch (Exception ex) { ex.printStackTrace(); JOptionPane.showMessageDialog(parent, "Erreur: " + ex.getMessage()); }
        });

        btnReturn.addActionListener(e -> {
            int sr = table.getSelectedRow();
            if (sr == -1) { JOptionPane.showMessageDialog(parent, "Sélectionnez un emprunt"); return; }
            int modelRow = table.convertRowIndexToModel(sr);
            int id = (int) model.getValueAt(modelRow, 0);
            try (java.sql.Connection conn = com.bibliotheque.util.DatabaseConnection.getConnection()) {
                boolean ok = dao.enregistrerRetour(conn, id, LocalDate.now());
                if (ok) JOptionPane.showMessageDialog(parent, "Retour enregistré"); else JOptionPane.showMessageDialog(parent, "Impossible d'enregistrer le retour");
                btnRefresh.doClick();
            } catch (Exception ex) { ex.printStackTrace(); JOptionPane.showMessageDialog(parent, "Erreur: " + ex.getMessage()); }
        });

        // initial load
        btnRefresh.doClick();
    }
}
