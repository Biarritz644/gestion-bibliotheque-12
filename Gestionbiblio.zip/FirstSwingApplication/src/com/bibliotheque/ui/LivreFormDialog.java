package com.bibliotheque.ui;

import com.bibliotheque.model.Livre;

import javax.swing.*;
import java.awt.*;

public class LivreFormDialog extends JDialog {

    private JTextField txtTitre = new JTextField(20);
    private JTextField txtAuteur = new JTextField(20);
    private JTextField txtAnnee = new JTextField(5);
    private JTextField txtQuantite = new JTextField(5);

    private boolean confirmed = false;
    private Livre livre;

    public LivreFormDialog(JFrame parent, Livre livre) {
        super(parent, true);
        setTitle(livre == null ? "Ajouter Livre" : "Modifier Livre");

        this.livre = livre;

        setLayout(new BorderLayout());

        JPanel form = new JPanel(new GridLayout(4,2,10,10));

        form.add(new JLabel("Titre:"));
        form.add(txtTitre);

        form.add(new JLabel("Auteur:"));
        form.add(txtAuteur);

        form.add(new JLabel("Année:"));
        form.add(txtAnnee);

        form.add(new JLabel("Quantité:"));
        form.add(txtQuantite);


        add(form, BorderLayout.CENTER);

        JButton btnOk = new JButton("Valider");
        JButton btnCancel = new JButton("Annuler");

        JPanel buttons = new JPanel();
        buttons.add(btnOk);
        buttons.add(btnCancel);

        add(buttons, BorderLayout.SOUTH);

        if(livre != null){
            txtTitre.setText(livre.getTitre());
            txtAuteur.setText(livre.getAuteur());
            txtAnnee.setText(String.valueOf(livre.getAnneeEdition()));
            txtQuantite.setText(String.valueOf(livre.getQuantite()));

        }

        btnOk.addActionListener(e -> {
            confirmed = true;
            dispose();
        });

        btnCancel.addActionListener(e -> dispose());

        pack();
        setLocationRelativeTo(parent);
    }

    public boolean isConfirmed() {
        return confirmed;
    }

    public Livre getLivre() {

        String titre = txtTitre.getText();
        String auteur = txtAuteur.getText();
        int annee = Integer.parseInt(txtAnnee.getText());
        int quantite = Integer.parseInt(txtQuantite.getText());

        if(livre == null){
            return new Livre(0, titre, auteur, annee, quantite);
        } else {
            return new Livre(livre.getId(), titre, auteur, annee, quantite);
        }

    }
}
