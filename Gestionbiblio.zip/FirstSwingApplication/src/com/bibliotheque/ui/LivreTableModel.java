package com.bibliotheque.ui;

import com.bibliotheque.model.Livre;

import javax.swing.table.AbstractTableModel;
import java.util.ArrayList;
import java.util.List;

public class LivreTableModel extends AbstractTableModel {
	
	
	private static final long serialVersionUID = 1L;


    private List<Livre> livres = new ArrayList<>();

    private final String[] columns = {
            "ID", "Titre", "Auteur", "Année","Quantité", "Disponible"
    };

    public void setLivres(List<Livre> livres){
        this.livres = livres;
        fireTableDataChanged();
    }

    @Override
    public int getRowCount() {
        return livres.size();
    }

    @Override
    public int getColumnCount() {
        return columns.length;
    }

    @Override
    public String getColumnName(int column) {
        return columns[column];
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {

        Livre livre = livres.get(rowIndex);

        switch (columnIndex){
            case 0: return livre.getId();
            case 1: return livre.getTitre();
            case 2: return livre.getAuteur();
            case 3: return livre.getAnneeEdition();
            case 4: return livre.getQuantite();
            case 5: return livre.isDisponible() ? "Oui" : "Non";
            default: return null;
        }
    }
}
