package com.bibliotheque.ui;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;

public class Screenshot {
    public static void main(String[] args) throws Exception {
        SwingUtilities.invokeLater(() -> {
            try {
                MainFrame frame = new MainFrame();
                frame.setVisible(true);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });

        // waiting for UI to render
        Thread.sleep(1500);

        Rectangle screenRect = new Rectangle(Toolkit.getDefaultToolkit().getScreenSize());
        BufferedImage capture = new Robot().createScreenCapture(screenRect);
        File out = new File("screenshot_ui.png");
        ImageIO.write(capture, "png", out);
        System.out.println("Screenshot saved to: " + out.getAbsolutePath());
        System.exit(0);
    }
}
