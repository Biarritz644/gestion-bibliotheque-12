package com.bibliotheque.ui.themes;

import java.awt.*;

public final class Theme {
    public static final Color SIDEBAR = Color.decode("#1F2D3D");
    public static final Color PRIMARY = Color.decode("#2E86C1");
    public static final Color SUCCESS = Color.decode("#27AE60");
    public static final Color WARNING = Color.decode("#F39C12");
    public static final Color DANGER = Color.decode("#E74C3C");
    public static final Color BACKGROUND = Color.decode("#F4F6F9");
    public static final Color TEXT = Color.decode("#2C3E50");

    public static final Font UI_FONT = new Font("Segoe UI", Font.PLAIN, 13);

    private Theme() {}
}
