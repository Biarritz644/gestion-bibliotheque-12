package com.bibliotheque.test;

import com.bibliotheque.dao.EmpruntDAO;
import com.bibliotheque.dao.LivreDAO;
import com.bibliotheque.dao.ClientDAO;
import com.bibliotheque.model.Client;
import com.bibliotheque.model.Livre;
import com.bibliotheque.util.DbInitializer;
import com.bibliotheque.util.DbSchemaInitializer;

import java.sql.Connection;
import java.sql.DriverManager;
import java.time.LocalDate;
import java.util.List;

public class TestCrud {
    public static void main(String[] args) throws Exception {
        // Ensure database
        DbInitializer.main(new String[]{});

        // Ensure schema
        DbSchemaInitializer.ensureSchema();

        LivreDAO ldao = new LivreDAO();
        ClientDAO cdao = new ClientDAO();
        EmpruntDAO edao = new EmpruntDAO();

        System.out.println("--- TEST CRUD START ---");

        // Create a book
        Livre livre = new Livre(0, "Test Livre", "Auteur T", 2020, 3);
        int lid = ldao.ajouterLivre(livre);
        System.out.println("Livre ajouté id=" + lid);

        // Create a client
        Client client = new Client(0, "Test Client", 30, "M");
        int cid = cdao.ajouterClient(client);
        System.out.println("Client ajouté id=" + cid);

        // Create emprunt (transaction)
        try (Connection conn = com.bibliotheque.util.DatabaseConnection.getConnection()) {
            conn.setAutoCommit(false);
            boolean updated = ldao.updateQuantite(conn, lid, -1);
            if (!updated) throw new RuntimeException("Impossible de décrémenter la quantité");
            int eid = edao.creerEmprunt(conn, lid, cid, LocalDate.now(), LocalDate.now().plusDays(14));
            conn.commit();
            System.out.println("Emprunt créé id=" + eid);
        }

        // Lister livres
        List<Livre> livres = ldao.getAllLivres();
        System.out.println("Livres total: " + livres.size());

        // Lister clients
        System.out.println("Clients total: " + cdao.getAllClients().size());

        System.out.println("--- TEST CRUD END ---");
    }
}
